from pydantic import BaseModel, ConfigDict
from typing import Optional


class DutTypeBase(BaseModel):
    type: str

class DutTypeCreate(DutTypeBase):
    pass

class DutTypeUpdate(DutTypeBase):
    pass

class DutType(DutTypeBase):
    id: int

    # class Config:
    #     orm_mode = True
    class Config:
        from_attributes = True



class DutBase(BaseModel):
    model_config = ConfigDict(protected_namespaces=())  # Disable protected namespaces
    
    manufacturer: str
    serial_number: str
    firmware_version: Optional[str] = None
    model_number: Optional[str] = None
    dut_type_id: int
    name: Optional[str] = None
    lbh: Optional[str] = None
    file_directory: Optional[str] = None

class DutCreate(DutBase):
    pass

class DutUpdate(DutBase):
    pass

class Dut(DutBase):
    id: int
    dut_type: Optional[DutType] = None  # Use the DutType schema here

    class Config:
        from_attributes = True
        # protected_namespaces = ()

class DutSearchParams(BaseModel):
    model_config = ConfigDict(protected_namespaces=())  # Disable protected namespaces
    
    name: Optional[str] = None
    manufacturer: Optional[str] = None
    model_number: Optional[str] = None
    serial_number: Optional[str] = None


# Dut_Button Schemas
class DutButtonsBase(BaseModel):
    dut_id: Optional[int] = None
    button_name: Optional[str] = None
    button_position: Optional[str] = None
    button_roi: Optional[str] = None
    light: Optional[bool] = None
    button_image: Optional[bytes] = None  # For binary data

class DutButtonsCreate(DutButtonsBase):
    pass

class DutButtonsUpdate(DutButtonsBase):
    pass

class DutButtonsInDB(DutButtonsBase):
    id: int

    class Config:
        from_attributes = True
        # orm_mode = True


# Dut_Screen Schemas

class DutScreensBase(BaseModel):
    screen_name: Optional[str] = None
    screen_position: Optional[str] = None
    screen_roi: Optional[str] = None
    light: Optional[bool] = False
    orientation: Optional[str] = None
    exposure: Optional[str] = None

class DutScreensCreate(DutScreensBase):
    dut_id: int  

class DutScreensUpdate(DutScreensBase):
    pass 

class DutScreensInDB(DutScreensBase):
    id: int
    dut_id: int

    class Config:
        from_attributes = True
        # orm_mode = True

# class OnClickNavigationRequest(BaseModel):
#     image_base64: str




class HapiCreate(BaseModel):
    id : Optional[int] = None
    action_name: str
    dut_id: int

class GetHapi(BaseModel):
    id: int
    action_name: str
    dut_id: int


class NavigationApiBase(BaseModel):
    hapi_id: Optional[int]
    order: int
    api: str
    name : str
    element_id : str


class NavigationApiCreate(BaseModel):
    id:Optional[int]
    hapi_id: int
    api: str
    name: Optional[str] = None
    element_id : str
    # Any additional fields

class NavigationApiUpdate(BaseModel):
    hapi_id: int
    api: str
    name: Optional[str] = None
    element_id : str

class NavigationApiOut(NavigationApiBase):
    id: int

    class Config:
        from_attributes = True