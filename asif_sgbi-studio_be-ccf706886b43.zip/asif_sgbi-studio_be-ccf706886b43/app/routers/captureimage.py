import cv2
import os

# Stream URL and save directory
# stream_url = "http://localhost:8081/?action=stream"  # URL of the video stream
stream_url = "http://192.168.29.72:8081/my_camera"  # URL of the video stream
save_directory = "/home/sgbi/Q_studio/studio_be/app/routers"  # Ensure this is an absolute path and you have write permissions

def capture_and_save_image(output_filename='output_img.jpg'):
    """
    Capture an image from a video stream, rotate it by 180 degrees, and save it to a specified directory.

    Args:
    - output_filename (str): The name of the output image file (default is 'output_img.jpg').

    Returns:
    - str: Path to the saved image file if successful, otherwise None.
    """

    # Open the video stream using OpenCV
    cap = cv2.VideoCapture(stream_url)
    print(stream_url)

    # Check if the video stream is opened successfully
    if not cap.isOpened():
        print(f"Error: Unable to open video stream at {stream_url}.")
        return None

    # Read a single frame from the stream
    ret, frame = cap.read()

    # If a frame is captured successfully
    if ret:
        # Rotate the frame by 180 degrees
        # rotated_frame = cv2.rotate(frame, cv2.ROTATE_180)
        # print(rotated_frame)

        # Create the save directory if it doesn't exist
        if not os.path.exists(save_directory):
            os.makedirs(save_directory)
            print(f"Created directory: {save_directory}")
        
        # Construct the full path to the output file
        output_path = os.path.join(save_directory, output_filename)

        # Save the rotated frame as an image file
        try:
            cv2.imwrite(output_path, frame)
            print(f"Image captured, rotated by 180 degrees, and saved as '{output_path}'")
        except Exception as e:
            print(f"Error saving image: {e}")
            output_path = None
    else:
        print("Error: Unable to capture image from the stream.")
        output_path = None

    # Release the video capture object
    cap.release()

    return output_path

# Call the function to capture, rotate, and save the image
capture_and_save_image()