import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import cv2
import base64
from .modules import Teach_Modules

teach_modules = Teach_Modules()

status,sr = teach_modules.init_serial_port()

router = APIRouter()


from typing import List
# active_connections: List[WebSocket] = []

def rotate_frame(frame, angle):
    if angle == 90:
        return cv2.rotate(frame, cv2.ROTATE_90_CLOCKWISE)
    elif angle == 180:
        return cv2.rotate(frame, cv2.ROTATE_180)
    elif angle == 270:
        return cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)
    else:
        return frame


# # last used
@router.websocket("/ws/video_feed")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    # active_connections.append(websocket)  # Add to active connections
    # print(active_connections)
    camera = cv2.VideoCapture(2)  # Use 0 for the default camera
    # camera = cv2.VideoCapture(0)  # Use 0 for the default camera

    # Set the resolution to 640x480

    camera.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 1440)
    camera.set(cv2.CAP_PROP_AUTO_EXPOSURE,0.75)
    camera.set(cv2.CAP_PROP_EXPOSURE,1500)  # Default to auto exposure


    try:
        while True:
            success, frame = camera.read()
            if not success:
                break

            # Rotate the frame by 90 degrees clockwise
            frame = rotate_frame(frame,180)  # Adjust rotation as needed
            frame = teach_modules.crop_image(frame)

            cv2.imwrite('/home/sgbi/Q_studio/studio_be/app/routers/output_image.jpg',frame)
            # Set JPEG quality parameter
            params = [int(cv2.IMWRITE_JPEG_QUALITY), 100]  # Quality from 0 to 100
            _, buffer = cv2.imencode('.jpg', frame, params)            

            frame = base64.b64encode(buffer).decode('utf-8')

            # shared_state.globalframe = frame
            base64.b64decode(frame)

            # Step 2: Write the binary data to a JPEG file
            # with open("output_image.jpg", "wb") as f:
            #     f.write(image_data)

            
            await websocket.send_text(frame)
    except WebSocketDisconnect:
        print("Client disconnected")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        camera.release()
        await websocket.close()







# @router.post("/reload_ws")
# async def reload_websocket_connections():
#     """
#     Reload or close all active WebSocket connections.
#     """
#     print(active_connections)
#     for connection in active_connections:
#         try:
#             print(connection)
#             await connection.close()
#         except Exception as e:
#             print(f"Error closing connection: {e}")

#     active_connections.clear()  # Clear all active connections

#     return {"status": "WebSocket connections reloaded"}



































# @router.websocket("/ws/video_feed")
# async def websocket_endpoint(websocket: WebSocket):
#     await websocket.accept()

#     # camera = cv2.VideoCapture(2)  # Initialize the camera globally (adjust camera index as needed)
#     camera.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
#     camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 1440)
#     camera.set(cv2.CAP_PROP_AUTO_EXPOSURE,0.75)
#     # camera.set(cv2.CAP_PROP_EXPOSURE,EXPO['expo'])  # Default to auto exposure


#     try:
#         while True:

#             # Capture and process the frame
#             #camera.set(cv2.CAP_PROP_EXPOSURE,EXPO['expo'])  # Default to auto exposure

#             success, frame = camera.read()
#             if not success:
#                 break

#             frame = rotate_frame(frame, 180)  # Adjust rotation if needed
#             frame = teach_modules.crop_image(frame)  # Crop or modify the frame as needed

#             # Encode the frame as JPEG
#             _, buffer = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 100])
#             frame_base64 = base64.b64encode(buffer).decode('utf-8')

#             # Send the frame to the client
#             await websocket.send_text(frame_base64)

#     except WebSocketDisconnect:
#         print("Client disconnected")
#     except Exception as e:
#         print(f"Error: {e}")
#     finally:
#         camera.release()
#         await websocket.close()

# @router.get("/set_exposure/{expo}")
# def set_exposure(expo: int):
#     global EXPO
#     #EXPO['expo'] = expo
#     # Query the Hapi records related to the specified dut_id
#     #EXPO = expo
#     # Return the list of Hapi records
#     #camera.set(cv2.CAP_PROP_EXPOSURE,expo)
#     print("Expo updated :",expo)
#     return expo




















