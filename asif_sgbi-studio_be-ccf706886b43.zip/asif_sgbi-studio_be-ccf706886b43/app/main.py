from fastapi import FastAPI, WebSocket
from . import models, database
from .routers import base_router, websocket_router, element_router, navigation_router, hapi_router, camcontrol
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import logging
import time
import os
import asyncio

app = FastAPI()

# Configure CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    # format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("app.log"),
    ]
)

from fastapi.responses import StreamingResponse
from typing import AsyncIterable
async def log_stream() -> AsyncIterable[str]:
    log_file_path = "app.log"
    
    # Check if the log file exists
    if not os.path.exists(log_file_path):
        yield "Log file not found."
        return
    
    with open(log_file_path, "r") as log_file:
        # Move the file pointer to the end of the file to start receiving new logs
        log_file.seek(0, os.SEEK_END)

        while True:
            line = log_file.readline()
            if line:
                yield f"data: {line.strip()}\n\n"
            else:
                # Wait for new logs to be written
                await asyncio.sleep(1)  # Use asyncio.sleep for non-blocking wait

@app.get("/logs")
async def get_logs():
    return StreamingResponse(log_stream(), media_type="text/event-stream")


# Create the database tables
models.Base.metadata.create_all(bind=database.engine)

# Include routers
# app.include_router(user_router.router)
app.include_router(base_router.router)
app.include_router(websocket_router.router)
app.include_router(element_router.router)
app.include_router(navigation_router.router)
app.include_router(hapi_router.router)
app.include_router(camcontrol.router)




# The static directory to serve files
app.mount("/static", StaticFiles(directory="app/static"), name="static")
