from fastapi import APIRouter
from . .import models, schemas, database


router = APIRouter()



# @router.post("/create_template/")