import base64
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
# from typing import List
from .. import crud, schemas, database, models
from .modules import Teach_Modules
# import modules
from .captureimage import*
import cv2
import time
import logging


logger = logging.getLogger(__name__)

router = APIRouter()

teach_modules = Teach_Modules()


status,sr = teach_modules.init_serial_port()
def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()





@router.post("/detect_cameras/")
def detect_camera_index():
    result = sr
    return result

@router.post("/get_current_pos/")
def get_current_pos():
    # teach_modules.init_serial_port(sr)

    result = teach_modules.get_current_pos(sr)
    return result


@router.get("/home/")
def home_node():
    """
    Endpoint to send the 'home' command to the robot.

    Returns:
    - JSON response containing the result of the 'home' command.
    """
    try:
        result = teach_modules.send_cmd(sr, "h:")
        if not result:
            logger.error("Failed to execute the 'home' command.")
            raise HTTPException(status_code=500, detail="Failed to execute the 'home' command.")
        
        logger.info("Executed the 'home' command successfully.")
        return {"result": result}
    
    except Exception as e:
        logger.error(f"Internal server error during 'home' command execution: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error.")
    


@router.get("/light")
def light_off():
    """
    Endpoint to turn off the light.

    Returns:
    - JSON response containing the result of the 'light off' command.
    """
    try:
        result = teach_modules.send_cmd(sr, "l:0:")
        if not result:
            logger.error("Failed to execute the 'light off' command.")
            raise HTTPException(status_code=500, detail="Failed to execute the 'light off' command.")
        
        logger.info("Executed the 'light off' command successfully.")
        return {"result": result}
    
    except Exception as e:
        logger.error(f"Internal server error during 'light off' command execution: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error.")
    


@router.get("/light_on")
def light_on():
    """
    Endpoint to turn on the light.

    Returns:
    - JSON response containing the result of the 'light on' command.
    """
    try:
        result = teach_modules.send_cmd(sr, "l:1:")
        if not result:
            logger.error("Failed to execute the 'light on' command.")
            raise HTTPException(status_code=500, detail="Failed to execute the 'light on' command.")
        
        logger.info("Executed the 'light on' command successfully.")
        return {"result": result}
    
    except Exception as e:
        logger.error(f"Internal server error during 'light on' command execution: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error.")


@router.post("/click_position_xy/{x}/{y}")
def click_position_xy(x : str, y : str):
    cmd = "m:"+x+":"+y+":100:"
    result = teach_modules.send_cmd(sr,cmd)
    return result



@router.post("/navbar_movement/{steps}/{direction}")
def movement_by_navbar(steps: int, direction: str):
    """
    Endpoint to move the robot using navbar controls.

    Args:
    - steps (int): Number of steps to move.
    - direction (str): Direction of movement (up, down, right, left).

    Returns:
    - JSON response containing the result of the movement.
    """
    # Validate direction input
    valid_directions = {"up", "down", "right", "left"}
    if direction not in valid_directions:
        logger.error(f"Invalid direction '{direction}' provided.")  # Log the error
        raise HTTPException(status_code=400, detail="Invalid direction. Choose from 'up', 'down', 'right', or 'left'.")

    try:
        # Get the current position from the robot
        status, x_pos, y_pos = teach_modules.get_current_pos(sr)
        if not status:
            logger.error("Failed to get the current position from the robot.")  # Log the error
            raise HTTPException(status_code=400, detail="Failed to get the current position from the robot.")

        # Move the robot based on the direction and steps
        result = teach_modules.move_robot(x_pos, y_pos, steps, direction, sr)

        # Log success
        logger.info(f"Robot moved {steps} steps to the {direction}. Current position: ({x_pos}, {y_pos})")
        return {"result": result}

    except ValueError as ve:
        # Handle specific errors during movement
        logger.error(f"Value error during robot movement: {str(ve)}")  # Log the specific error
        raise HTTPException(status_code=400, detail=f"Value error: {str(ve)}")

    except Exception as e:
        # Handle any unexpected errors
        logger.error(f"Internal server error during navbar movement: {str(e)}")  # Log the generic error
        raise HTTPException(status_code=500, detail="Internal server error.")


@router.post("/onclick_navigation/{x}/{y}/")
async def onclick_navigation(x: int, y: int):
    """
    Endpoint to handle navigation clicks based on x and y pixel coordinates.

    Args:
    - x (int): The x-coordinate of the click.
    - y (int): The y-coordinate of the click.

    Returns:
    - JSON response containing a message and the coordinates.
    """
    try:
        capture_and_save_image()
        # Move the robot by pixel based on x and y coordinates with a "left_click" action
        result = teach_modules.move_robot_by_pixel(sr, x, y, "left_click")
        # If the robot movement is not successful, raise an exception
        if not result:
            logger.error(f"Failed to move the robot to coordinates ({x}, {y})")  # Log the error
            raise ValueError("Failed to move the robot.")

        # Log success
        logger.info(f"Robot moved to coordinates ({x}, {y}) successfully")  
        return {"message": "Action performed successfully", "x": x, "y": y}

    except ValueError as ve:
        logger.error(f"Error in moving robot: {str(ve)}")  # Log the error
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(ve))

    except Exception as e:
        logger.error(f"Internal server error during onclick navigation: {str(e)}")  # Log the generic error
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Internal server error: {str(e)}")


@router.post("/right_onclick_navigation/{x}/{y}/{duration}/{back_pos}/{force}/")
def right_onclick_navigation(x: int, y: int, duration: str, back_pos: str, force: str): 
    """
    Endpoint to handle right-click navigation with additional parameters for duration, back position, and force.

    Args:
    - x (int): The x-coordinate for the navigation click.
    - y (int): The y-coordinate for the navigation click.
    - duration (str): Duration for which the click action should be held.
    - back_pos (str): Back position parameter for navigation.
    - force (str): Force parameter for the click action.

    Returns:
    - JSON response containing the result of the robot movement.
    """
    try:
        # Capture an image and save it
        capture_and_save_image()

        # Perform the robot movement based on provided parameters
        result, feedback = teach_modules.move_robot_by_pixel(sr, x, y, "right_click", duration, back_pos, force)
        print('result :',result)
        # Check if the result indicates a successful operation
        if not result:
            raise ValueError("Failed to move the robot with the given parameters.")
        result = result.split(":")
        result = {'x':result[2], 'y':result[3]}
        return {"message": "Action performed successfully", "result": result, "feedback" : feedback }

    except ValueError as ve:
        # Handle specific errors such as failure in robot movement
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(ve))

    except Exception as e:
        # Handle generic errors
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Internal server error: {str(e)}")



@router.post("/move_to_element_pos/{element_pos}/")
def move_to_element_pos(element_pos: str):
    """
    Endpoint to move the robot to a specified element position.

    Args:
    - element_pos (str): The element position to move to.

    Returns:
    - JSON response containing the result of the move command.
    """
    # Validate element_pos input format
    # if not element_pos or not element_pos.isdigit():
    #     logger.error(f"Invalid element position '{element_pos}' provided.")
    #     raise HTTPException(status_code=400, detail="Invalid element position format. Must be a numeric string.")
    print(element_pos)
    # Construct the command to send to the robot
    cmd = f"m:{element_pos}:100:"
    try:
        # Send the command to the robot
        pos = teach_modules.send_cmd(sr, cmd)
        if not pos:
            logger.error(f"Failed to execute move command to element position '{element_pos}'.")
            raise HTTPException(status_code=500, detail="Failed to execute move command.")

        # Log success
        logger.info(f"Successfully moved to element position '{element_pos}'.")
        return {"result": pos}
    
    except Exception as e:
        # Log unexpected errors
        logger.error(f"Internal server error during move command execution: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error.")




@router.get("/low_level_apitest/{script}/{element_id}/")
def run_low_level_api( script: str,element_id : str, db: Session = Depends(get_db)):
    target = element_id.split(':')[0]
    print(target)
    element_id = element_id.split(':')[1]
    if target == "BTN":
        print("BTN Operation")
        db_button = crud.get_dut_button(db, button_id=element_id)
        if db_button is None:
            raise HTTPException(status_code=404, detail="Dut button not found")
        
        element_pos = db_button.button_position
        cmd = "m:" + element_pos + ":100:"
        pos = teach_modules.send_cmd(sr, cmd)
        time.sleep(0.5)
        element_pos = element_pos.split(':')

        # light = int(db_button.light)
        light = "1" 
        cmd = "l:" + str(light) + ":"
        pos = teach_modules.send_cmd(sr, cmd)
        capture_and_save_image()

        btn_image = db_button.button_image
        btn_image = base64.b64decode(btn_image)
        with open("btn_image.jpg", "wb") as f:
                    f.write(btn_image)
        btn_image = cv2.imread("btn_image.jpg")

        btn_roi = db_button.button_roi
        btn_roi = btn_roi.split(":")
        print("Btn roi :",btn_roi)
    
        #element_point = [[int(float(btn_roi[0])), int(float(btn_roi[1]))], [int(float(btn_roi[2])), int(float(btn_roi[3]))]]
        element_point = [[int(float(btn_roi[0]))-10, int(float(btn_roi[1]))-10], [int(float(btn_roi[0]))+ int(float(btn_roi[2]))+10, int(float(btn_roi[1])) +int(float(btn_roi[3]))+10]]

        img = cv2.imread("/home/sgbi/Q_studio/studio_be/app/routers/output_img.jpg")
        # Continue processing the frame
        out, cent, i = teach_modules.find_element( btn_image, element_point, rotation=False)
        # cmd = "f:str:ied4:10:10:200:"
        cmd = script
        
        cmd_split = cmd.split(':')

        if cent != False:

            real_cmd = teach_modules.center_to_mm(cmd_split,cent,int(element_pos[0]),int(element_pos[1]))
            final_cmd = cmd.replace(str(db_button.button_name),real_cmd)
            print("Centerrrrrrrrrrrrrrrrfffffffffff :",final_cmd)
            cv2.imwrite('/home/sgbi/Q_studio/studio_be/app/routers/temp_image.jpg',out)
            pos = teach_modules.send_cmd(sr, final_cmd)
            print(final_cmd)
            print(pos)

        else:
            print("False")
        # return {"center": '..........'}
        
        return pos

    elif target == "CAP" or target == "SCR":

        print("CAP Operation")
        db_screen = crud.get_dut_screen(db, screen_id= element_id)
        if db_screen is None:
            raise HTTPException(status_code=404, detail="Dut Screen not found")
        if target == "CAP":

            print("CAPTURE Found.....!")
             
            screen_pos = db_screen.screen_position
            cmd = "m:" + screen_pos + ":100:"
            pos = teach_modules.send_cmd(sr, cmd)
            time.sleep(1)
            screen_pos = screen_pos.split(':')

            # light = int(db_button.light)
            light = "1"
            cmd = "l:" + str(light) + ":"
            pos = teach_modules.send_cmd(sr, cmd)
            capture_and_save_image()

            screeb_roi = db_screen.screen_roi
            screeb_roi = screeb_roi.split(":")
            print("Btn roi :",screeb_roi)
            #element_point = [[int(float(screeb_roi[0]))-10, int(float(screeb_roi[1]))-10], [int(float(screeb_roi[0]))+ int(float(screeb_roi[2]))+10, int(float(screeb_roi[1])) +int(float(screeb_roi[3]))+10]]

            x  = int(float(screeb_roi[0]))
            y  = int(float(screeb_roi[1]))
            x1 = int(float(screeb_roi[0])) + int(float(screeb_roi[2]))
            y1 = int(float(screeb_roi[1])) + int(float(screeb_roi[3]))

            
            img = cv2.imread("/home/sgbi/Q_studio/studio_be/app/routers/output_img.jpg")

            image = img[y:y1, x:x1]

            cv2.imwrite("/home/sgbi/Q_studio/studio_be/tempimg/capture_img.jpg",image)


            # Encode the cropped image to Base64
            _, buffer = cv2.imencode('.jpg', image)
            captured_image = base64.b64encode(buffer).decode('utf-8')

            # Return the Base64 string as a JSON response
            return {"captured_image": captured_image}

        else:
            target == "SCR"
            print("Screen move Found.....!")

            db_screen = crud.get_dut_screen(db, screen_id= element_id)
            if db_screen is None:
                raise HTTPException(status_code=404, detail="Dut Screen not found")
            
            screen_pos = db_screen.screen_position
            cmd = "m:" + screen_pos + ":100:"
            pos = teach_modules.send_cmd(sr, cmd)
            time.sleep(1)
            screen_pos = screen_pos.split(':')

            # light = int(db_button.light)
            light = "1"
            cmd = "l:" + str(light) + ":"
            pos = teach_modules.send_cmd(sr, cmd)
            capture_and_save_image()
            return pos
            
    elif target == "SWS" or target == "SWD":
            capture_and_save_image()
            
            pos = teach_modules.send_cmd(sr, script)

            # return final_cmd
            return {"final_cmd": script}
 
            
    elif target == "MAT" or  target == "MAP":
            capture_and_save_image()
            
            pos = teach_modules.send_cmd(sr, script)

            # return final_cmd
            return {"result": pos}
        



@router.post("/swipe_pxl_to_mm/{script}")
def swipe_pxl_to_mm(script: str):
    try:
        capture_and_save_image()

        # Get the current position from the module
        status, x_pos, y_pos = teach_modules.get_current_pos(sr)
        if not status:
            logger.error("Failed to get the current position from the robot.")  # Log the error
            raise HTTPException(status_code=400, detail="Failed to get the current position from the robot.")

        # Split and validate the command script
        cmd_split = script.split(':')
        if len(cmd_split) < 7:
            logger.error(f"Invalid script format: {script}")  # Log invalid script error
            raise HTTPException(status_code=400, detail="Invalid script format. Ensure the script has the correct format.")

        # Convert pos frm pxls to mm
        pos1 = (int(cmd_split[1]), int(cmd_split[2]))
        pos2 = (int(cmd_split[3]), int(cmd_split[4]))

        # Calculate start and end coordinates in millimeters
        start_xy = teach_modules.center_to_mm(cmd_split, pos1, int(x_pos), int(y_pos))
        end_xy = teach_modules.center_to_mm(cmd_split, pos2, int(x_pos), int(y_pos))

        # Construct the final command to be sent
        final_cmd = f"{cmd_split[0]}:{start_xy}:{end_xy}:{cmd_split[5]}:{cmd_split[6]}:"
        logger.info(f"Executing final command: {final_cmd}")  # Log the successful execution of the command

        # Send the command to the robot
        teach_modules.send_cmd(sr, final_cmd)

        return {"command": final_cmd}

    except ValueError as ve:
        # Handle specific conversion errors or processing errors
        logger.error(f"Value error during processing: {str(ve)}")  # Log the specific error
        raise HTTPException(status_code=400, detail=f"Value error: {str(ve)}")

    except Exception as e:
        # Handle any unexpected errors
        logger.error(f"Internal server error during swipe processing: {str(e)}")  # Log the generic error
        raise HTTPException(status_code=500, detail="Internal server error.")







@router.get("/low_level_api/{button_id}/")
def run_low_level_api( button_id: int, db: Session = Depends(get_db)):
    db_button = crud.get_dut_button(db, button_id)
    if db_button is None:
        raise HTTPException(status_code=404, detail="Dut button not found")
    
    element_pos = db_button.button_position
    cmd = "m:" + element_pos + ":100:"
    pos = teach_modules.send_cmd(sr, cmd)

    element_pos = element_pos.split(':')

    # light = int(db_button.light)
    light = "1"
    cmd = "l:" + str(light) + ":"
    pos = teach_modules.send_cmd(sr, cmd)

    btn_image = db_button.button_image
    btn_image = base64.b64decode(btn_image)
    with open("btn_image.jpg", "wb") as f:
                f.write(btn_image)
    btn_image = cv2.imread("btn_image.jpg")

    btn_roi = db_button.button_roi
    btn_roi = btn_roi.split(":")
    print("Btn roi :",btn_roi)
   
    #element_point = [[int(float(btn_roi[0])), int(float(btn_roi[1]))], [int(float(btn_roi[2])), int(float(btn_roi[3]))]]
    element_point = [[int(float(btn_roi[0]))-10, int(float(btn_roi[1]))-10], [int(float(btn_roi[0]))+ int(float(btn_roi[2]))+10, int(float(btn_roi[1])) +int(float(btn_roi[3]))+10]]

    img = cv2.imread("/home/sgbi/Q_studio/studio_be/app/routers/output_img.jpg")
    # Continue processing the frame
    out, cent, i = teach_modules.find_element(img, btn_image, element_point, rotation=False)
    cmd = "f:str:ied4:10:10:200:"
    
    cmd_split = cmd.split(':')

    if cent != False:

        real_cmd = teach_modules.center_to_mm(cmd_split,cent,int(element_pos[0]),int(element_pos[1]),img)
        final_cmd = cmd.replace(str(db_button.button_name),real_cmd)
        print("Centerrrrrrrrrrrrrrrrfffffffffff :",final_cmd)
        cv2.imwrite('/home/sgbi/Q_studio/studio_be/app/routers/temp_image.jpg',out)
        pos = teach_modules.send_cmd(sr, final_cmd)
        print(real_cmd)
        print(pos)

    else:
        print("False")
    return {"center": '..........'}



























# import base64
# from PIL import Image
# from io import BytesIO
# from fastapi import APIRouter, HTTPException
# from pydantic import BaseModel

# router = APIRouter()

# # Define the request schema
# class OnClickNavigationRequest(BaseModel):
#     image_base64: str

# @router.post("/onclick_navigation/{x}/{y}/")
# async def onclick_navigation(x: int, y: int, request: OnClickNavigationRequest):
#     try:
#         # Print the coordinates
#         print(x, y)
        
#         # Decode the base64 string
#         base64_string = request.image_base64
#         image_data = base64.b64decode(base64_string)
        
#         # Convert to an image
#         image = Image.open(BytesIO(image_data))
        
#         # Define the path to save the image
#         image_path = f"/home/sgbi/testimg/image_{x}_{y}.png"
        
#         # Save the image to the specified path
#         image.save(image_path)

#         # Process the image and coordinates
#         result = teach_modules.move_robot_by_pixel(sr, base64_string, x, y, "left_click")
        
#         # Return a success message
#         return {"message": "Image decoded and saved successfully", "x": x, "y": y}

#     except Exception as e:
#         # Return an error message if something goes wrong
#         raise HTTPException(status_code=400, detail=f"Error processing request: {str(e)}")




























































#     @router.get("/low_level_apitest/{script}/{element_id}/")
# def run_low_level_api(script: str, element_id: str, db: Session = Depends(get_db)):
#     """
#     Endpoint to perform low-level API operations based on the script and element ID.

#     Args:
#     - script (str): The script to execute.
#     - element_id (str): The element ID used to determine the operation type.

#     Returns:
#     - JSON response containing the result of the operation.
#     """
#     try:
#         target = element_id.split(':')[0]
#         element_id = element_id.split(':')[1]

#         if target == "BTN":
#             logger.info("BTN Operation")
#             db_button = crud.get_dut_button(db, button_id=element_id)
#             if db_button is None:
#                 logger.error(f"Dut button with ID {element_id} not found.")
#                 raise HTTPException(status_code=404, detail="Dut button not found")

#             element_pos = db_button.button_position
#             cmd = f"m:{element_pos}:100:"
#             pos = teach_modules.send_cmd(sr, cmd)
#             time.sleep(0.5)
#             element_pos = element_pos.split(':')

#             light = "1"
#             cmd = f"l:{light}:"
#             pos = teach_modules.send_cmd(sr, cmd)
#             capture_and_save_image()

#             btn_image = base64.b64decode(db_button.button_image)
#             with open("btn_image.jpg", "wb") as f:
#                 f.write(btn_image)
#             btn_image = cv2.imread("btn_image.jpg")

#             btn_roi = db_button.button_roi.split(":")
#             element_point = [
#                 [int(float(btn_roi[0])) - 10, int(float(btn_roi[1])) - 10],
#                 [int(float(btn_roi[0])) + int(float(btn_roi[2])) + 10, int(float(btn_roi[1])) + int(float(btn_roi[3])) + 10]
#             ]

#             img = cv2.imread("/home/sgbi/Q_studio/studio_be/app/routers/output_img.jpg")
#             out, cent, i = teach_modules.find_element(btn_image, element_point, rotation=False)
#             cmd_split = script.split(':')

#             if cent:
#                 real_cmd = teach_modules.center_to_mm(cmd_split, cent, int(element_pos[0]), int(element_pos[1]))
#                 final_cmd = script.replace(str(db_button.button_name), real_cmd)
#                 logger.info(f"Executing final command: {final_cmd}")
#                 cv2.imwrite('/home/sgbi/Q_studio/studio_be/app/routers/temp_image.jpg', out)
#                 pos = teach_modules.send_cmd(sr, final_cmd)
#                 logger.info(f"Command executed successfully: {pos}")
#             else:
#                 logger.error("Failed to find the element.")
#                 raise HTTPException(status_code=400, detail="Failed to find the element.")

#             return {"result": pos}

#         elif target in {"CAP", "SCR"}:
#             if target == "CAP":
#                 logger.info("CAP Operation")
#                 db_screen = crud.get_dut_screen(db, screen_id=element_id)
#                 if db_screen is None:
#                     logger.error(f"Dut screen with ID {element_id} not found.")
#                     raise HTTPException(status_code=404, detail="Dut Screen not found")

#                 screen_pos = db_screen.screen_position
#                 cmd = f"m:{screen_pos}:100:"
#                 pos = teach_modules.send_cmd(sr, cmd)
#                 time.sleep(1)
#                 screen_pos = screen_pos.split(':')

#                 light = "1"
#                 cmd = f"l:{light}:"
#                 pos = teach_modules.send_cmd(sr, cmd)
#                 capture_and_save_image()

#                 screeb_roi = db_screen.screen_roi.split(":")
#                 x, y, x1, y1 = int(float(screeb_roi[0])), int(float(screeb_roi[1])), int(float(screeb_roi[0])) + int(float(screeb_roi[2])), int(float(screeb_roi[1])) + int(float(screeb_roi[3]))

#                 img = cv2.imread("/home/sgbi/Q_studio/studio_be/app/routers/output_img.jpg")
#                 image = img[y:y1, x:x1]
#                 cv2.imwrite("/home/sgbi/Q_studio/studio_be/tempimg/capture_img.jpg", image)

#                 _, buffer = cv2.imencode('.jpg', image)
#                 captured_image = base64.b64encode(buffer).decode('utf-8')

#                 return {"captured_image": captured_image}

#             elif target == "SCR":
#                 logger.info("SCR Operation")
#                 db_screen = crud.get_dut_screen(db, screen_id=element_id)
#                 if db_screen is None:
#                     logger.error(f"Dut screen with ID {element_id} not found.")
#                     raise HTTPException(status_code=404, detail="Dut Screen not found")

#                 screen_pos = db_screen.screen_position
#                 cmd = f"m:{screen_pos}:100:"
#                 pos = teach_modules.send_cmd(sr, cmd)
#                 time.sleep(1)
#                 screen_pos = screen_pos.split(':')

#                 light = "1"
#                 cmd = f"l:{light}:"
#                 pos = teach_modules.send_cmd(sr, cmd)
#                 capture_and_save_image()

#                 return {"result": pos}

#         elif target in {"SWS", "SWD", "MAT", "MAP"}:
#             capture_and_save_image()
#             pos = teach_modules.send_cmd(sr, script)
#             logger.info(f"Executed script command: {script} with result: {pos}")
#             return {"result": pos}

#         else:
#             logger.error(f"Invalid target '{target}' provided.")
#             raise HTTPException(status_code=400, detail="Invalid target provided.")

#     except Exception as e:
#         logger.error(f"Internal server error during low-level API test: {str(e)}")
#         raise HTTPException(status_code=500, detail="Internal server error.")