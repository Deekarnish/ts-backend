from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from .. import crud, schemas, database, models

router = APIRouter()

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/create_dut_types/", response_model=schemas.DutType)
def create_dut_type(dut_type: schemas.DutTypeCreate, db: Session = Depends(get_db)):
    return crud.create_dut_type(db=db, dut_type=dut_type)

@router.get("/get_duttypes/{dut_type_id}", response_model=schemas.DutType)
def read_dut_type(dut_type_id: int, db: Session = Depends(get_db)):
    db_dut_type = crud.get_dut_type(db, dut_type_id=dut_type_id)
    if db_dut_type is None:
        raise HTTPException(status_code=404, detail="Dut_Type not found")
    return db_dut_type

@router.get("/list_dut_types/", response_model=List[schemas.DutType])
def read_dut_types(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    dut_types = crud.get_dut_types(db, skip=skip, limit=limit)
    return dut_types

@router.put("/duttypes/{dut_type_id}", response_model=schemas.DutType)
def update_dut_type(dut_type_id: int, dut_type: schemas.DutTypeUpdate, db: Session = Depends(get_db)):
    db_dut_type = crud.update_dut_type(db, dut_type_id=dut_type_id, dut_type=dut_type)
    if db_dut_type is None:
        raise HTTPException(status_code=404, detail="Dut_Type not found")
    return db_dut_type

@router.delete("/duttypes/{dut_type_id}")
def delete_dut_type(dut_type_id: int, db: Session = Depends(get_db)):
    db_dut_type = crud.delete_dut_type(db, dut_type_id=dut_type_id)
    if db_dut_type is None:
        raise HTTPException(status_code=404, detail="Dut_Type not found")
    return {"detail": "Dut_Type deleted"}



@router.post("/create_dut/", response_model=schemas.Dut)
def create_dut(dut: schemas.DutCreate, db: Session = Depends(get_db)):
    return crud.create_dut(db=db, dut=dut)

@router.get("/dut/{dut_id}")
def read_dut(dut_id: int, db: Session = Depends(get_db)):
    db_dut = crud.get_dut(db=db, dut_id=dut_id)
    if db_dut is None:
        raise HTTPException(status_code=404, detail="Dut not found")
    return db_dut

@router.get("/list_duts/")
def read_duts( db: Session = Depends(get_db)):
    duts = crud.get_duts(db=db)
    return duts

@router.put("/update_dut/{dut_id}", response_model=schemas.Dut)
def update_dut(dut_id: int, dut: schemas.DutUpdate, db: Session = Depends(get_db)):
    db_dut = crud.update_dut(db=db, dut_id=dut_id, dut=dut)
    if db_dut is None:
        raise HTTPException(status_code=404, detail="Dut not found")
    return db_dut

@router.delete("/delete_dut/{dut_id}", response_model=schemas.Dut)
def delete_dut(dut_id: int, db: Session = Depends(get_db)):
    db_dut = crud.delete_dut(db=db, dut_id=dut_id)
    if db_dut is None:
        raise HTTPException(status_code=404, detail="Dut not found")
    return db_dut

@router.get("/duts/search/", response_model=List[schemas.DutSearchParams])
def search_dut(
    params: schemas.DutSearchParams = Depends(),
    db: Session = Depends(get_db)
):
    query = db.query(models.Dut)
    
    if params.name:
        query = query.filter(models.Dut.name.ilike(f"%{params.name}%"))
    if params.manufacturer:
        query = query.filter(models.Dut.manufacturer.ilike(f"%{params.manufacturer}%"))
    if params.model_number:
        query = query.filter(models.Dut.model_number.ilike(f"%{params.model_number}%"))
    if params.serial_number:
        query = query.filter(models.Dut.serial_number.ilike(f"%{params.serial_number}%"))
    
    results = query.all()
    return results