from sqlalchemy import Column, Integer, String, ForeignKey, LargeBinary, Boolean, UniqueConstraint
from sqlalchemy.orm import relationship
from .database import Base



class Dut_Type(Base):
    __tablename__ = "duttypes"
    id = Column(Integer, primary_key=True, index=True)
    type = Column(String(50), index=True)  

    # Define a relationship to the Dut model
    duts = relationship("Dut", back_populates="dut_type")




class Dut(Base):
    __tablename__ = "dut"

    id = Column(Integer, primary_key=True, index=True)
    manufacturer = Column(String(100), index=True)
    serial_number = Column(String(100), index=True)
    firmware_version = Column(String(50))
    model_number = Column(String(100))
    dut_type_id = Column(Integer, ForeignKey('duttypes.id'))  # Foreign key to Dut_Type
    name = Column(String(100))
    lbh = Column(String(100))  # Assuming LBH stands for a code or identifier
    file_directory = Column(String(255))

    # Define a relationship to the Dut_Type model
    dut_type = relationship("Dut_Type", back_populates="duts")

    # Define a relationship to the Dut_Buttons model
    buttons = relationship("Dut_Buttons", back_populates="dut")

    # Define a relationship to the Dut_Screens model
    screens = relationship("Dut_Screens", back_populates="dut")

    hapis = relationship("Hapi", back_populates="dut")



class Dut_Buttons(Base):
    __tablename__ = "dutbutton"

    id = Column(Integer, primary_key=True, index=True)
    dut_id = Column(Integer, ForeignKey('dut.id'))
    button_name = Column(String(100))
    button_position = Column(String(50))
    button_roi = Column(String(100))  
    light = Column(Boolean)
    button_image = Column(LargeBinary)  # Store image as BLOB

    # Define a relationship to the Dut model
    dut = relationship("Dut", back_populates="buttons")



class Dut_Screens(Base):
    __tablename__ = "dutscreen"

    id = Column(Integer, primary_key=True, index=True)
    screen_name = Column(String(100))
    screen_position = Column(String(50))
    screen_roi = Column(String(100))  
    light = Column(Boolean)
    orientation = Column(String(100))  
    exposure = Column(String(100))  
    dut_id = Column(Integer, ForeignKey('dut.id'))

    # Define a relationship to the Dut model
    dut = relationship("Dut", back_populates="screens")



class Hapi(Base):
    __tablename__ = "hapi"

    id = Column(Integer, primary_key=True, index=True)
    action_name = Column(String(150))
    dut_id = Column(Integer, ForeignKey('dut.id'))
    
    # Define a relationship to the Dut model
    dut = relationship("Dut", back_populates="hapis")

    # Relationship to Navigation_api
    navigation_apis = relationship("Navigation_Apis", back_populates="hapi", cascade="all, delete")



class Navigation_Apis(Base):
    __tablename__ = "navigation_apis"

    id = Column(Integer, primary_key=True, index=True)
    hapi_id = Column(Integer, ForeignKey('hapi.id', ondelete='CASCADE'), nullable=False)
    order = Column(Integer, nullable=False)
    api = Column(String(100), nullable=False)
    name = Column(String(100) )
    element_id = Column(String(100), nullable=False) # [BTN : 23]

    
    # Establish a back-populating relationship with Hapi
    hapi = relationship("Hapi", back_populates="navigation_apis")

    # __table_args__ = (UniqueConstraint('hapi_id', 'name', name='_hapi_name_uc'),)
