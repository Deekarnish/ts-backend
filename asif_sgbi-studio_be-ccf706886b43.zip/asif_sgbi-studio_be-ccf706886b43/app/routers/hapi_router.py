from fastapi import APIRouter, HTTPException, Depends, status
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from . .import models, schemas, database
from typing import List
from sqlalchemy import func
from fastapi.responses import JSONResponse
import logging
def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

router = APIRouter()

logger = logging.getLogger(__name__)

@router.post("/create_hapi/", response_model=schemas.HapiCreate)
def create_hapi(hapi: schemas.HapiCreate, db: Session = Depends(get_db)):
    """
    Create a new Hapi record.

    Args:
        hapi (schemas.HapiCreate): The Hapi schema with the data for the new record.
        db (Session, optional): Database session dependency.

    Returns:
        schemas.HapiCreate: The created Hapi record.
    """
    try:
        # Check for duplicates within the same dut_id
        logger.info(f"Checking for duplicate action_name within DUT ID: {hapi.dut_id}")
        existing_hapi = db.query(models.Hapi).filter(
            models.Hapi.action_name == hapi.action_name,
            models.Hapi.dut_id == hapi.dut_id
        ).first()

        if existing_hapi:
            logger.warning(f"Duplicate action_name '{hapi.action_name}' found for DUT ID {hapi.dut_id}")
            raise HTTPException(status_code=400, detail="action_name must be unique within this DUT")
        
        # Create new Hapi instance
        logger.info("Creating new Hapi record")
        new_hapi = models.Hapi(**hapi.model_dump())
        db.add(new_hapi)
        db.commit()
        db.refresh(new_hapi)

        logger.info(f"New Hapi record created successfully with ID: {new_hapi.id}")
        return new_hapi

    except Exception as e:
        logger.error(f"Error creating Hapi record: {e}")
        raise HTTPException(status_code=500, detail="An error occurred while creating the Hapi record.")


@router.delete("/delete_hapi/{hapi_id}")
def delete_hapi(hapi_id: int, db: Session = Depends(get_db)):
    """
    Delete a Hapi record and its related Navigation_api records.

    Args:
        hapi_id (int): The ID of the Hapi record to delete.
        db (Session, optional): Database session dependency.

    Returns:
        dict: A message confirming deletion of the Hapi and related records.
    """
    try:
        logger.info(f"Attempting to delete Hapi record with ID: {hapi_id}")
        hapi_to_delete = db.query(models.Hapi).filter(models.Hapi.id == hapi_id).first()

        # If the record doesn't exist, raise a 404 error
        if not hapi_to_delete:
            logger.warning(f"Hapi record with ID {hapi_id} not found")
            raise HTTPException(status_code=404, detail="Hapi not found")

        # Delete all related Navigation_api records
        logger.info(f"Deleting related Navigation_api records for Hapi ID: {hapi_id}")
        db.query(models.Navigation_Apis).filter(models.Navigation_Apis.hapi_id == hapi_id).delete()

        # Delete the Hapi record
        logger.info(f"Deleting Hapi record with ID: {hapi_id}")
        db.delete(hapi_to_delete)
        db.commit()

        logger.info(f"Hapi record with ID {hapi_id} and related records deleted successfully")
        return {"detail": "Hapi and related records deleted successfully"}

    except Exception as e:
        logger.error(f"Error deleting Hapi record with ID {hapi_id}: {e}")
        raise HTTPException(status_code=500, detail="An error occurred while deleting the Hapi record.")



@router.get("/hapi/by-dut/{dut_id}", response_model=List[schemas.GetHapi])
def get_hapis_by_dut(dut_id: int, db: Session = Depends(get_db)):
    # Query the Hapi records related to the specified dut_id
    hapi_list = db.query(models.Hapi).filter(models.Hapi.dut_id == dut_id).all()

    # Return the list of Hapi records
    return hapi_list


# Create a Navigation API entry
@router.post("/lowlevel_script/", response_model=schemas.NavigationApiCreate)
def create_navigation_api(
    hapi_id: int, 
    api: str, 
    name: str, 
    element_id: str,
    db: Session = Depends(get_db)
):
    # Check if a navigation with the same name and hapi_id already exists
    # existing_navigation = db.query(models.Navigation_Apis).filter(
    #     models.Navigation_Apis.hapi_id == hapi_id,
    #     models.Navigation_Apis.name == name
    # ).first()

    # if existing_navigation:
    #     raise HTTPException(status_code=400, detail=f"A navigation with the name '{name}' already exists for this Hapi.")

    # Find the current maximum order value for the given hapi_id
    max_order = db.query(func.max(models.Navigation_Apis.order)).filter(
        models.Navigation_Apis.hapi_id == hapi_id
    ).scalar()
    next_order = (max_order or 0) + 1

    # Create a new Navigation_api record
    new_navigation_api = models.Navigation_Apis(hapi_id=hapi_id, order=next_order, api=api, name=name, element_id=element_id)
    
    try:
        db.add(new_navigation_api)
        db.commit()
        db.refresh(new_navigation_api)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"A navigation with the name '{name}' already exists for this Hapi.")

    # Convert the SQLAlchemy model instance to a Pydantic model before returning
    return schemas.NavigationApiCreate(
        id = new_navigation_api.id,
        hapi_id=new_navigation_api.hapi_id,
        api=new_navigation_api.api,
        name=new_navigation_api.name,
        element_id=new_navigation_api.element_id,
        order = new_navigation_api.order
    )



# Read Navigation API entries by hapi_id
@router.get("/lowlevel_script/by-hapi/{hapi_id}", response_model=List[schemas.NavigationApiOut])
def get_navigation_apis_by_hapi(hapi_id: int, db: Session = Depends(get_db)):
    nav_apis = db.query(models.Navigation_Apis).filter(models.Navigation_Apis.hapi_id == hapi_id).order_by(models.Navigation_Apis.order).all()
    return nav_apis

# Update a Navigation API entry
@router.put("/update_lowlevel_script/{nav_id}/", response_model=schemas.NavigationApiUpdate)
def update_navigation_api(nav_id: int, nav_api_update: schemas.NavigationApiUpdate, db: Session = Depends(get_db)):
    nav_api = db.query(models.Navigation_Apis).filter(models.Navigation_Apis.id == nav_id).first()
    if not nav_api:
        raise HTTPException(status_code=404, detail="Navigation API not found")
    
    for key, value in nav_api_update.model_dump().items():
        setattr(nav_api, key, value)
    
    db.commit()
    db.refresh(nav_api)
    return nav_api



# Delete a Navigation API entry
@router.delete("/delete_lowlevel_script/{navigation_id}", status_code=status.HTTP_200_OK)
def delete_navigation_api(navigation_id: int, db: Session = Depends(get_db)):
    # Fetch the navigation entry to be deleted
    navigation_to_delete = db.query(models.Navigation_Apis).filter(models.Navigation_Apis.id == navigation_id).first()

    if not navigation_to_delete:
        raise HTTPException(status_code=404, detail="Navigation entry not found")

    hapi_id = navigation_to_delete.hapi_id
    order_to_remove = navigation_to_delete.order

    try:
        # Delete the navigation entry
        db.delete(navigation_to_delete)

        # Commit the deletion
        db.commit()

        # Reorder remaining entries
        # Fetch remaining entries that need to be reordered
        remaining_entries = db.query(models.Navigation_Apis).filter(
            models.Navigation_Apis.hapi_id == hapi_id,
            models.Navigation_Apis.order > order_to_remove
        ).order_by(models.Navigation_Apis.order).all()

        # Update the order of the remaining entries
        for idx, entry in enumerate(remaining_entries):
            entry.order = order_to_remove + idx  # Ensure the order is sequential after deletion

        # Commit the reordering
        db.commit()

    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error occurred while deleting the navigation entry.")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {str(e)}")

    return JSONResponse(content={"detail": "Navigation entry deleted and remaining entries reordered successfully."}, status_code=status.HTTP_200_OK)