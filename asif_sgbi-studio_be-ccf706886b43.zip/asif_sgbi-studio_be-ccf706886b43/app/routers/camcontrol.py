from fastapi import APIRouter, HTTPException
import subprocess

router = APIRouter()

DEVICE = "/dev/video2"  # Update this to your camera device file

def run_v4l2_command(command: str):
    try:
        subprocess.run(command, check=True, shell=True)
    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=f"Failed to execute command: {e}")

@router.post("/set_auto_exposure/{mode}")
def set_auto_exposure(mode: int):
    """
    Sets the auto exposure mode.
    """
    if mode not in [0, 1, 2, 3]:  # Assuming 0-3 are valid modes
        raise HTTPException(status_code=400, detail="Invalid mode value. Valid values are 0, 1, 2, 3.")
    run_v4l2_command(f"v4l2-ctl -d {DEVICE} --set-ctrl=auto_exposure={mode}")
    return {"message": f"Auto exposure mode set to {mode}"}

@router.post("/set_exposure_time_absolute/{value}")
def set_exposure_time_absolute(value: int):
    """
    Sets the absolute exposure time.
    """
    if not (1 <= value <= 10000):
        raise HTTPException(status_code=400, detail="Exposure time must be between 1 and 10000.")
    run_v4l2_command(f"v4l2-ctl -d {DEVICE} --set-ctrl=exposure_time_absolute={value}")
    return {"message": f"Exposure time set to {value}"}




from fastapi import FastAPI, HTTPException
import cv2
from mjpeg_streamer import MjpegServer, Stream
from threading import Thread

# app = FastAPI()

# Global dictionaries to hold the camera resources
camera_configs = [
    {"id": 0, "port": 8080, "width": 1280, "height": 720, "fps": 30, "quality": 80},
    {"id": 2, "port": 8081, "width": 640, "height": 480, "fps": 15, "quality": 60},
]

streams = {}
servers = {}
threads = {}
caps = {}


def start_camera_stream(camera_id: int):
    """Function to start the camera stream."""
    config = next((cfg for cfg in camera_configs if cfg["id"] == camera_id), None)
    if not config:
        raise ValueError(f"Camera configuration for ID {camera_id} not found.")
    
    # Open the camera
    cap = cv2.VideoCapture(config["id"])
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, config["width"])
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config["height"])
    cap.set(cv2.CAP_PROP_FPS, config["fps"])
    
    # Initialize MJPEG stream
    stream = Stream(f"camera_{config['id']}", quality=config["quality"], fps=config["fps"])
    server = MjpegServer("0.0.0.0", config["port"])
    server.add_stream(stream)
    server.start()

    # Store camera and stream references globally
    caps[camera_id] = cap
    streams[camera_id] = stream
    servers[camera_id] = server

    # Thread to read frames and update stream
    def stream_thread():
        while True:
            ret, frame = cap.read()
            if not ret:
                print(f"Failed to capture frame from camera {camera_id}. Exiting.")
                break
            
            # Rotate the frame 180 degrees if needed
            frame = cv2.rotate(frame, cv2.ROTATE_180)
            stream.set_frame(frame)
    
    # Start the thread
    thread = Thread(target=stream_thread)
    threads[camera_id] = thread
    thread.start()



def stop_camera_stream(camera_id: int):
    """Function to stop the camera stream."""
    if camera_id not in caps or camera_id not in servers:
        raise ValueError(f"Camera with ID {camera_id} is not running.")
    
    # Stop the server and release resources
    if caps[camera_id].isOpened():
        caps[camera_id].release()
    
    servers[camera_id].stop()  # Stop the MJPEG server
    threads[camera_id].join()  # Ensure the thread exits

    # Remove references
    del caps[camera_id]
    del streams[camera_id]
    del servers[camera_id]
    del threads[camera_id]


@router.post("/start/{camera_id}")
def start_stream(camera_id: int):
    """API endpoint to start a camera stream."""
    if camera_id in servers:
        raise HTTPException(status_code=400, detail="Camera is already streaming.")
    try:
        start_camera_stream(camera_id)
        return {"status": "Camera stream started", "camera_id": camera_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop/{camera_id}")
def stop_stream(camera_id: int):
    """API endpoint to stop a camera stream."""
    if camera_id not in servers:
        raise HTTPException(status_code=400, detail="Camera is not streaming.")
    try:
        stop_camera_stream(camera_id)
        return {"status": "Camera stream stopped", "camera_id": camera_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
from pydantic import BaseModel
class ExposureModel(BaseModel):
    exposure_value: float  # Exposure value (can be positive or negative depending on camera)

@router.post("/set_exposure/{camera_id}")
def set_exposure(camera_id: int, exposure: ExposureModel):
    """API endpoint to set the exposure of a camera."""
    if camera_id not in caps:
        raise HTTPException(status_code=400, detail="Camera is not streaming.")
    
    cap = caps[camera_id]
    try:
        # Set exposure value for the camera
        cap.set(cv2.CAP_PROP_EXPOSURE, exposure.exposure_value)
        return {"status": "Exposure set", "camera_id": camera_id, "exposure_value": exposure.exposure_value}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
