from typing import Optional
from sqlalchemy.orm import Session, joinedload
from . import models, schemas
from sqlalchemy.exc import IntegrityError
from fastapi import HTTPException, status




# Dut_Type CRUD functions
def create_dut_type(db: Session, dut_type: schemas.DutTypeCreate):
    db_dut_type = models.Dut_Type(type=dut_type.type)
    db.add(db_dut_type)
    db.commit()
    db.refresh(db_dut_type)
    return db_dut_type

def get_dut_type(db: Session, dut_type_id: int):
    return db.query(models.Dut_Type).filter(models.Dut_Type.id == dut_type_id).first()

def get_dut_types(db: Session, skip: int = 0, limit: int = 10):
    return db.query(models.Dut_Type).offset(skip).limit(limit).all()

def update_dut_type(db: Session, dut_type_id: int, dut_type: schemas.DutTypeUpdate):
    db_dut_type = db.query(models.Dut_Type).filter(models.Dut_Type.id == dut_type_id).first()
    if db_dut_type:
        db_dut_type.type = dut_type.type
        db.commit()
        db.refresh(db_dut_type)
    return db_dut_type

def delete_dut_type(db: Session, dut_type_id: int):
    db_dut_type = db.query(models.Dut_Type).filter(models.Dut_Type.id == dut_type_id).first()
    if db_dut_type:
        db.delete(db_dut_type)
        db.commit()
    return db_dut_type


# CRUD Operations of Dut

def create_dut(db: Session, dut: schemas.DutCreate):
    db_dut = models.Dut(**dut.model_dump())
    db.add(db_dut)
    db.commit()
    db.refresh(db_dut)
    return db_dut

def get_dut(db: Session, dut_id: int):
    return db.query(models.Dut).filter(models.Dut.id == dut_id).first()

def get_duts(db: Session):
    return db.query(models.Dut).all()

def update_dut(db: Session, dut_id: int, dut: schemas.DutUpdate):
    db_dut = db.query(models.Dut).filter(models.Dut.id == dut_id).first()
    if db_dut:
        for key, value in dut.model_dump().items():
            setattr(db_dut, key, value)
        db.commit()
        db.refresh(db_dut)
    return db_dut

def delete_dut(db: Session, dut_id: int):
    db_dut = db.query(models.Dut).options(joinedload(models.Dut.dut_type)).filter(models.Dut.id == dut_id).first()
    if db_dut:
        db.delete(db_dut)
        db.commit()
        return db_dut
    return None


# CRUD Operations of Dut_Buttons

def create_dut_button(db: Session, dut_button: schemas.DutButtonsCreate, button_pos) -> models.Dut_Buttons:
    # Check if button_name is unique for the given dut_id
    existing_button = db.query(models.Dut_Buttons).filter(
        models.Dut_Buttons.dut_id == dut_button.dut_id,
        models.Dut_Buttons.button_name == dut_button.button_name).first()

    if existing_button:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Button name must be unique for this DUT ID")
    print("button_position",button_pos)
    # Create the Dut_Buttons object with the calculated position
    db_button = models.Dut_Buttons(
        dut_id=dut_button.dut_id,
        button_name=dut_button.button_name,
        button_position=button_pos,  # Set the calculated position
        button_roi=dut_button.button_roi,
        light=dut_button.light,
        button_image=dut_button.button_image
    )
    print(db_button.button_position)
    
    db.add(db_button)
    try:
        db.commit()
        db.refresh(db_button)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Failed to create button")
    return db_button


def get_dut_button(db: Session, button_id: int) -> Optional[models.Dut_Buttons]:
    return db.query(models.Dut_Buttons).filter(models.Dut_Buttons.id == button_id).first()

def get_dut_buttons(db: Session, dut_id: int):
    return db.query(models.Dut_Buttons).filter(models.Dut_Buttons.dut_id == dut_id).all()

def update_dut_button(db: Session, button_id: int, dut_button: schemas.DutButtonsUpdate, button_pos: str) -> Optional[models.Dut_Buttons]:
    # Fetch the button to be updated
    db_button = db.query(models.Dut_Buttons).filter(models.Dut_Buttons.id == button_id).first()

    if not db_button:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Button not found")

    # Update fields that are provided in the update request
    for key, value in dut_button.dict(exclude_unset=True).items():
        setattr(db_button, key, value)

    # Ensure that the updated button_name is unique for the dut_id
    if dut_button.button_name and dut_button.button_name != db_button.button_name:
        existing_button = db.query(models.Dut_Buttons).filter(
            models.Dut_Buttons.dut_id == db_button.dut_id,
            models.Dut_Buttons.button_name == dut_button.button_name
        ).first()

        if existing_button:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Button name must be unique for this DUT ID")

    # Update the button_position with the provided value
    db_button.button_position = button_pos

    try:
        db.commit()
        db.refresh(db_button)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Failed to update button")
    
    return db_button

def delete_dut_button(db: Session, button_id: int) -> Optional[models.Dut_Buttons]:
    db_dut_button = db.query(models.Dut_Buttons).filter(models.Dut_Buttons.id == button_id).first()
    if db_dut_button:
        db.delete(db_dut_button)
        db.commit()
    return db_dut_button

# def get_dut_buttons(db: Session, dut_id: int, skip: int = 0, limit: int = 10):
#     return db.query(models.Dut_Buttons).filter(models.Dut_Buttons.dut_id == dut_id).offset(skip).limit(limit).all()

# CRUD Operations of Dut_Screens

def create_dut_screen(db: Session, dut_screen: schemas.DutScreensCreate, screen_pos: str):
    # Check if screen_name is unique for the given dut_id
    existing_screen = db.query(models.Dut_Screens).filter(
        models.Dut_Screens.dut_id == dut_screen.dut_id,
        models.Dut_Screens.screen_name == dut_screen.screen_name
    ).first()

    if existing_screen:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Screen name must be unique for this DUT ID")

    # Create the Dut_Screens object with the calculated position
    db_screen = models.Dut_Screens(
        screen_name=dut_screen.screen_name,
        screen_position=screen_pos,  # Set the calculated position
        screen_roi=dut_screen.screen_roi,
        light=dut_screen.light,
        orientation=dut_screen.orientation,
        exposure=dut_screen.exposure,
        dut_id=dut_screen.dut_id
    )
    
    db.add(db_screen)
    try:
        db.commit()
        db.refresh(db_screen)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Failed to create screen")
    return db_screen

def get_dut_screen(db: Session, screen_id: int):
    return db.query(models.Dut_Screens).filter(models.Dut_Screens.id == screen_id).first()

def get_dut_screens_by_dut_id(db: Session, dut_id: int):
    return db.query(models.Dut_Screens).filter(models.Dut_Screens.dut_id == dut_id).all()

def update_dut_screen(db: Session, screen_id: int, dut_screen: schemas.DutScreensUpdate, screen_pos: str) -> Optional[models.Dut_Screens]:
    db_screen = db.query(models.Dut_Screens).filter(models.Dut_Screens.id == screen_id).first()

    if not db_screen:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Screen not found")

    # Update fields that are provided in the update request
    for key, value in dut_screen.model_dump(exclude_unset=True).items():
        setattr(db_screen, key, value)

    # Ensure that the updated screen_name is unique for the dut_id
    if dut_screen.screen_name and dut_screen.screen_name != db_screen.screen_name:
        existing_screen = db.query(models.Dut_Screens).filter(
            models.Dut_Screens.dut_id == db_screen.dut_id,
            models.Dut_Screens.screen_name == dut_screen.screen_name
        ).first()

        if existing_screen:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Screen name must be unique for this DUT ID")

    # Update the screen_position with the provided value
    db_screen.screen_position = screen_pos

    try:
        db.commit()
        db.refresh(db_screen)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Failed to update screen")
    
    return db_screen

def delete_dut_screen(db: Session, screen_id: int) -> Optional[models.Dut_Screens]:
    db_dut_screen = db.query(models.Dut_Screens).filter(models.Dut_Screens.id == screen_id).first()
    if db_dut_screen:
        db.delete(db_dut_screen)
        db.commit()
    return db_dut_screen
