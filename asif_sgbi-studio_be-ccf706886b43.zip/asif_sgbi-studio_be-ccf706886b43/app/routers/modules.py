import cv2
import qrcode
import pickle

#import easyocr
import numpy as np
import cv2.aruco as aruco
from imutils import perspective
from pyzbar.pyzbar import decode
from spellchecker import SpellChecker
#from keras.models import load_model
from PIL import Image, ImageOps

import re
import time
import os
import subprocess
from difflib import SequenceMatcher
import serial.tools.list_ports
from os.path import exists

#import keras_ocr
#import pytesseract
##from paddleocr import PaddleOCR
#for qualcom

import imutils
import difflib
import base64


ROBOT_MIN_X     = 0
ROBOT_MAX_X     = 250
ROBOT_MIN_Y     = 0
ROBOT_MAX_Y     = 230
SPEED           = '100'
running_step    = 10
MOVE_SPEED      = '100'
pixel_mm_ratio  = 9.017712910970053 #5.433333333333334

CROP_START_Y    = 160
CROP_END_Y      = 1280
CROP_START_X    = 35
CROP_END_X      = 1885

OFFSET_X        = 0
OFFSET_Y        = 0

CAM_OFFSET_X    = 47.5
CAM_OFFSET_Y    = 0 

class Teach_Modules():
    def __init__(self, full_path = '' , easy=["english_g2"], draw=False, gpu=False):
        

        # globals()["reader_english_g2"] = easyocr.Reader(['en'], gpu=False, recog_network = "english_g2")
        # for i in easy:
        #     if i!="english_g2":
        #         globals()["reader_"+str(i)] = easyocr.Reader(['en'], gpu=False, recog_network = i)#"english_g2")

        self.ser = None
        self.ser_connected = False
        self.full_path = full_path
        self.draw = draw
        self.ARUCO_DICT =  {"DICT_6X6_1000": cv2.aruco.DICT_6X6_1000}
        #self.calib = np.load(self.full_path + 'config/calibration_file/calib.npz')
        #self.status_model = load_model(self.full_path + 'config/status_detection/keras_model.h5',compile=False)
        
    def crop_reorder(self, point1, point2):
        #point1(top-left),point2(bottom-right)
        try:
            if point1[0]>point2[0]:
                x1,x2=point2[0],point1[0]
            else:
                x1,x2=point1[0],point2[0]
            if point1[1]>point2[1]:
                y1,y2=point2[1],point1[1]
            else:
                y1,y2=point1[1],point2[1]
            return (x1,y1), (x2,y2)
        except Exception as e:
            print(e)
            
    def detect_display(self, img, display_area_percent):
        #logging.info('detect_display function called')
        try:
            img1 = img.copy()
            w,h,_ = img1.shape
            display_area = int((w*h*display_area_percent)/200)
            display_area = 0
            gray = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY) #convert to greyscale
            # Apply bilateral filter with d=5, sigmaColor = sigmaSpace = 75.
            blur = cv2.bilateralFilter(gray, 5, 75, 75) #blur image
            mask = cv2.threshold(blur,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)[1] #threshold image
            size = np.size(mask)
            ones = cv2.countNonZero(mask)
            zeros = size - ones
            if ones<zeros:
                mask = cv2.bitwise_not(mask)
            kernel = np.ones((3, 3), np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cnt = sorted(contours, key = cv2.contourArea, reverse = True)[:1][0]
            area = cv2.contourArea(cnt)
            if area > display_area: #filter according to area
                rect = cv2.minAreaRect(cnt) #find enclosing rectangle
                (x, y), (w, h), angle = rect
                box = cv2.boxPoints(rect)
                display_box = np.int0(box)
                center  = (int(x),int(y))
                #logging.debug('detect_display function found screen')
                if self.draw == True: #draw boxes
                        cv2.circle(img1, center, 5, (0, 0, 255), -1)
                        cv2.polylines(img1, [display_box], True, (255, 0, 0), 2)
                        for i in display_box:
                            cv2.circle(img1, (i[0], i[1]), 10, (0, 0, 255), -1)   
                display = perspective.four_point_transform(img, display_box)
                return display_box, display
            else:
                #logging.error('detect_display function found no screen')
                return False, False
        except Exception as e:
            print(e)
            #logging.error('detect_display function error: \n'+str(e))
    
    def adjust_gamma(self, image, gamma=1.0): #correct gamma
        #logging.info('adjust_gamma function called')
        try:
            gamma = 0.01*gamma
            invGamma = 1.0 / gamma
            table = np.array([((i / 255.0) ** invGamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
            return cv2.LUT(image, table)
        except Exception as e:
            print(e)
            #logging.error('adjust_gamma function error: \n'+str(e))
   
    def map(self, x, in_min, in_max, out_min, out_max):
        #logging.info('map function called')
        try:
            return int((x-in_min) * (out_max-out_min) / (in_max-in_min) + out_min)
        except Exception as e:
            print(e)
            #logging.error('map function error: \n'+str(e))
    
    def apply_brightness_contrast(self, input_img, brightness=255, contrast=127): #adjust brightness and contrast
        #logging.info('apply_brightness_contrast function called')
        try:
            brightness = self.map(brightness, 0, 510, -255, 255)
            contrast = self.map(contrast, 0, 254, -127, 127)
            if brightness != 0:
                if brightness > 0:
                    shadow = brightness
                    highlight = 255
                else:
                    shadow = 0
                    highlight = 255 + brightness
                alpha_b = (highlight - shadow)/255
                gamma_b = shadow
                buf = cv2.addWeighted(input_img, alpha_b, input_img, 0, gamma_b)
            else:
                buf = input_img.copy()
            if contrast != 0:
                f = float(131 * (contrast + 127)) / (127 * (131 - contrast))
                alpha_c = f
                gamma_c = 127*(1-f)
                buf = cv2.addWeighted(buf, alpha_c, buf, 0, gamma_c)
            return buf
        except Exception as e:
            print(e)
            #logging.error('apply_brightness_contrast function error: \n'+str(e))
    
    def glare_corr(self, img, clipLimit=2.0, tileGridSize=8, sigma_s=10, sigma_r=15): #remove glare
        img = cv2.fastNlMeansDenoising(img,None,10,7,21)
        img = cv2.detailEnhance(img, sigma_s=sigma_s, sigma_r=sigma_r*0.01)
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        lab_planes = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=clipLimit,tileGridSize=(tileGridSize,tileGridSize))
        lab_planes[0] = clahe.apply(lab_planes[0])
        lab = cv2.merge(lab_planes)
        clahe_bgr = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
        return clahe_bgr
    
    def hsv_filter(self, image,hMin,sMin,vMin,hMax,sMax,vMax): #Filter hsv image 
        #Set minimum and max HSV(Hue Saturation Value) values to display
        lower = np.array([hMin, sMin, vMin])
        upper = np.array([hMax, sMax, vMax])
        # Apply bilateral filter with d=5, sigmaColor = sigmaSpace = 175.
        blurred = cv2.bilateralFilter(image, 5, 175, 175)
        # Create HSV Image and threshold into a range.
        hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, lower, upper)
        return mask
    
    def size_filter(self, image,min_size): #Remove small noise
        nb_components, output, stats, centroids = cv2.connectedComponentsWithStats(image, connectivity=8)
        sizes = stats[1:, -1]; nb_components = nb_components - 1
        img2 = np.zeros((output.shape))
        for i in range(0, nb_components):
            #print(sizes[i])
            if sizes[i] >= min_size:
                img2[output == i + 1] = 255
        img2 = np.uint8(img2)
        mask = cv2.bitwise_not(img2)
        return mask
    
    def color_picker(self, image, hMin,sMin,vMin,hMax,sMax,vMax, min_size, brightness, contrast,gamma):
        #logging.info('color_picker function called')
        try:
            w,h,_ = image.shape
            #image = self.glare_corr(image)
            res_image = self.apply_brightness_contrast(image, brightness, contrast)
            res_image = self.adjust_gamma(res_image, gamma)
            #cv2.imshow("bright_contrast", res_image)
            mask= self.hsv_filter(res_image,hMin,sMin,vMin,hMax,sMax,vMax)
            kernel = np.ones((1, 1), np.uint8) #kernel size(1) depends on size of image
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            not_img = cv2.bitwise_not(mask)
            mask = self.size_filter(not_img,min_size)
            mask = cv2.dilate(mask,kernel,iterations=3)
            # rony.......
            ##ones = cv2.countNonZero(mask)
            #print("ones :",ones)
            #............
            #cv2.imshow("mask", mask)
            return mask
        except Exception as e:
            print(e)
            #logging.error('color_picker function error: \n'+str(e))

    def highlight_line_picker(self, image, hMin,sMin,vMin,hMax,sMax,vMax, min_size, brightness, contrast,gamma):
        try:
            w,h,_ = image.shape
            #image = self.glare_corr(image)
            res_image = self.apply_brightness_contrast(image, brightness, contrast)
            res_image = self.adjust_gamma(res_image, gamma)
            #cv2.imshow("bright_contrast", res_image)
            mask= self.hsv_filter(res_image,hMin,sMin,vMin,hMax,sMax,vMax)
            #cv2.imwrite(str(l_no)+'org.jpg',image)
            #cv2.imwrite(str(l_no)+'.jpg',mask)
            kernel = np.ones((1, 1), np.uint8) #kernel size(1) depends on size of image
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            not_img = cv2.bitwise_not(mask)
            mask = self.size_filter(not_img,min_size)
            mask = cv2.dilate(mask,kernel,iterations=3)
            #cv2.imwrite(str(l_no)+'.jpg',mask)
            # rony.......
            ones = cv2.countNonZero(mask)
            #print("ones :",ones)
            #............
            #cv2.imshow("mask", mask)
            return ones
        except Exception as e:
            print(e)
            
    def aruco_reader(self,img, origid,draw=True):
        try:
            status = False #if origid==detected_id
            imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            for (arucoName, arucoDict) in self.ARUCO_DICT.items():
                # load the ArUCo dictionary, grab the ArUCo parameters, and attempt to detect the markers for the current dictionary
                arucoDict = cv2.aruco.Dictionary_get(arucoDict)
                arucoParams = cv2.aruco.DetectorParameters_create()
                bbox, ids, rejected = aruco.detectMarkers(imgGray, arucoDict, parameters= arucoParams)
                # if at least one ArUco marker was detected display the ArUco name to our terminal
                if len(bbox) > 0:
                    print("[INFO] detected {} markers for '{} with ids {}'".format(len(bbox), arucoName, ids))
                    if draw==True:
                        aruco.drawDetectedMarkers(img, bbox, borderColor= (255,0,255)) # ids, borderColor= (255,0,255))
                    if str(ids[0][0]) == str(origid):
                        status = True
                        return img, status, bbox[0]
                        break
                    else:
                        print('aruco_reader function did not find matching a Aruco')
                    #cv2.imshow("aruco",img)
            print("Aruco not detected")
            print('aruco_reader function found no Aruco')
            return False, False, False
        except Exception as e:
            print(e)
            print('aruco_reader function error: \n'+str(e))

    def px_mm(self,bbox, markerSide_mm):
        try:
            #markerSide_mm, length of a side of an aruco
            perimeter = cv2.arcLength(bbox, True)
            #print(perimeter)
            pixel_mm_ratio = perimeter/(markerSide_mm*4) #px/mm
            #print(pixel_mm_ratio)
            return pixel_mm_ratio
        except Exception as e:
            print(e)
            print('px_mm function error: \n'+str(e))

    def find_diff(self,img, point1, point2, pixel_mm_ratio,draw=True): #point1=start point2=end # point 1:cam cent , point 2 :det cent
        try:
            y_distance = abs(point1[1]-point2[1])/pixel_mm_ratio
            x_distance = abs(point1[0]-point2[0])/pixel_mm_ratio
            if draw:
                cv2.circle(img, point1, 5, (255,255,255), -1)
                cv2.circle(img, point2, 5, (255,255,255), -1)
                cv2.line(img, point1, (point1[0], point2[1]), (255,255,0),3)
                cv2.line(img, point1, (point2[0], point1[1]), (0,255,255),3)    
                cv2.line(img, point2, (point1[0], point2[1]), (0,255,255),3)
                cv2.line(img, point2, (point2[0], point1[1]), (255,255,0),3)    
                cv2.putText(img, str(int(x_distance))+"mm", (int((point1[0]+point2[0])/2),point1[1]-20), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 1 , cv2.LINE_AA)
                cv2.putText(img, str(int(y_distance))+"mm", (point2[0]+10,int((point1[1]+point2[1])/2)), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,0), 1 , cv2.LINE_AA)
            if point1[0]>=point2[0]:
                x_distance = -1*x_distance
                #x_distance = x_distance*-1 # 
                #print("if part worked................")
            else:
                x_distance = x_distance
                #print("else part worked................")
            if point1[1]>=point2[1]:
                y_distance = -1*y_distance
            else:
                y_distance = y_distance

            #print(x_distance, y_distance) #in mm
            return img, x_distance, y_distance
        except Exception as e:
            print(e)
            print('find_diff function error: \n'+str(e))
            
    def inverse_points(self,M,points): #inverse the transformed points
        M_inv = np.linalg.pinv(M)
        #M_inv = cv2.getPerspectiveTransform(pts2,pts1)
        #print(M_inv)
        #points = np.array([[point]], dtype=np.float32)
        points = np.float32([points])
        transformed = cv2.perspectiveTransform(points, M_inv)
        return transformed[0]

    def rotate_bound(self,image, angle):
        # grab the dimensions of the image and then determine the
        # center
        (h, w) = image.shape[:2]
        (cX, cY) = (w / 2, h / 2)
        # grab the rotation matrix (applying the negative of the
        # angle to rotate clockwise), then grab the sine and cosine
        # (i.e., the rotation components of the matrix)
        M = cv2.getRotationMatrix2D((cX, cY), -angle, 1.0)
        cos = np.abs(M[0, 0])
        sin = np.abs(M[0, 1])
        # compute the new bounding dimensions of the image
        nW = int((h * sin) + (w * cos))
        nH = int((h * cos) + (w * sin))
        # adjust the rotation matrix to take into account translation
        M[0, 2] += (nW / 2) - cX
        M[1, 2] += (nH / 2) - cY
        # perform the actual rotation and return the image
        rotated = cv2.warpAffine(image, M, (nW, nH))
        M = np.append(M,[[0, 0, 1]], axis=0)
        return rotated, M

    def find_element(self,template,points,rotation=True,threshold=0.45,draw=True):
        try:
            print("Find Element..................................................")
            img = cv2.imread("/home/sgbi/Q_studio/studio_be/app/routers/output_img.jpg")
            
            #points = [(topleft),(bottomright)] ROI
            center=()
            point1,point4 = self.crop_reorder(points[0],points[1])
            img_roi = img[point1[1]:point4[1], point1[0]:point4[0]]
            cv2.imwrite("/home/sgbi/Q_studio/studio_be/app/routers/roi_area.jpg",img_roi)
            img_roi_gray = cv2.cvtColor(img_roi, cv2.COLOR_BGR2GRAY)
            template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
            #cv2.imshow("img_roi", img_roi)
            #cv2.imwrite("tempimg.jpeg",img_roi)
            (tH, tW) = template_gray.shape[:2]
            #for i in range(0,360,3): #rotate mage from 0-360 at 3 degree step
            #cv2.imwrite("img_roi_gray.jpg",img_roi_gray)
            #cv2.imwrite("template_gray.jpg",template_gray)
            for i in range(-20,20,1): #rotate mage from 0-360 at 3 degree step
                img_roi_gray1 = img_roi_gray.copy()
                if rotation == True:
                    img_roi_gray1,M = self.rotate_bound(img_roi_gray1, i)
                '''cv2.imshow("winname", img_roi_gray1)
                cv2.waitKey(500)
                cv2.destroyAllWindows()'''
                #print("for loop count :",i)
                res = cv2.matchTemplate(img_roi_gray1,template_gray,cv2.TM_CCOEFF_NORMED)
                (_, maxVal, _, maxLoc) = cv2.minMaxLoc(res)
                #print("MAx Value :",maxVal)
                #print("res :",res)
                #print("threshold :",threshold)
                #print("Maxlocs :",maxLoc)
                if maxVal>threshold:
                    # loop over the final bounding boxes
                    (startX, startY, endX, endY) = (maxLoc[0], maxLoc[1], maxLoc[0]+tW, maxLoc[1]+tH)
                    # draw the bounding box on the image
                    pointxy = [[startX, startY],[endX, endY]]
                    print("angle="+str(i))
                    print(maxVal)
                    #if i!=0 and:
                    if i!=0 and rotation == True:
                        transformed = self.inverse_points(M,pointxy)
                        #print(transformed)
                        startX, startY = transformed[0][0]+point1[0], transformed[0][1]+point1[1]
                        endX, endY = transformed[1][0]+point1[0], transformed[1][1]+point1[1]
                        center = (int((startX+endX)/2),int((startY+endY)/2))#-25)#25 offset added
                    else: 

                        (startX, startY, endX, endY) = (maxLoc[0]+point1[0], maxLoc[1]+point1[1], maxLoc[0]+point1[0]+tW, maxLoc[1]+point1[1]+tH)
                        center = (int((startX+endX)/2),int((startY+endY)/2))#-25)#25 offset added


                    #print(startX, startY)
                    #print(endX, endY)
                    #print(center)
                    if draw:
                        output_img = cv2.rectangle(img, (int(startX), int(startY)), (int(endX), int(endY)), (0, 0, 255), 3)
                        output_img = cv2.circle(img, center, 3,(255,255,255),-1)
                    else:
                        output_img = img
                    return output_img, center, i
                    break
            if center == ():
                print('find_element function did not find element')
                return False, False , False
        except Exception as e:
            print('find_element function error: \n'+str(e))

    def find_icon(self, img , template ,rotation=True ,threshold= 40,draw=True):
        try:
            print("Find Icon..........................................")
            threshold = threshold/100
            result = None
            gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            template_1 = template

            if rotation == True:
                rotations = [ cv2.cv2.ROTATE_90_CLOCKWISE , cv2.cv2.ROTATE_180 , cv2.cv2.ROTATE_90_COUNTERCLOCKWISE]
                for rot in rotations:       
                    result ,img = self.match(template_1 , gray_image ,img,threshold,draw)
                    if result != None:
                        break
                    template_1 = cv2.rotate(template, rot)

            else:
                print("yes here...")
                result ,img = self.match(template , gray_image ,img,threshold,draw)
            
            return result , img

        except Exception as e:
            print('find_element function error: \n'+str(e))

    def match(self,template,gray_image,real_img ,threshold,draw):
        try:
            temp_found = None
            result = None

            tmplt_mask = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)

            template = cv2.Canny(template, 10, 25)
            (height, width) = template.shape[:2]

            #cv2.imwrite("temp.jpg",template)
            #cv2.imwrite("org.jpg",gray_image)

            for scale in np.linspace(0.2, 1.0, 20)[::-1]:
                #resize the image and store the ratio
                resized_img = imutils.resize(gray_image, width = int(gray_image.shape[1] * scale))
                ratio = gray_image.shape[1] / float(resized_img.shape[1])
                if resized_img.shape[0] < height or resized_img.shape[1] < width:
                    break
                #Convert to edged image for checking
                processed_img = cv2.Canny(resized_img, 10, 25)
                #match = cv2.matchTemplate(processed_img, template, cv2.TM_CCORR_NORMED, mask=tmplt_mask )
                match = cv2.matchTemplate(processed_img, template, cv2.TM_CCORR_NORMED)
                #(_, val_max, _, loc_max) = cv2.minMaxLoc(match)
                (val_min, val_max, loc_min, loc_max) = cv2.minMaxLoc(match) # New  minVal,maxVal,minLoc,maxLoc = cv2.minMaxLoc(res)

                max_val_ncc = '{:.3f}'.format(val_max)
                print("correlation match score: " + max_val_ncc)

                #if float(max_val_ncc) > 0.375 and max_val_ncc != 'inf':
                if float(max_val_ncc) >= threshold and max_val_ncc != 'inf':
                    if temp_found is None or val_max>temp_found[0]:
                        temp_found = (val_max, loc_max, ratio)
                        
                        #Get information from temp_found to compute x,y coordinate
                        (_, loc_max, r) = temp_found
                        (x_start, y_start) = (int(loc_max[0]), int(loc_max[1]))
                        (x_end, y_end) = (int((loc_max[0] + width)), int((loc_max[1] + height)))
                        
                        center = (int((loc_max[0] + (width/2))), int((loc_max[1] + (height/2))))
                        #center = (int((loc_max[0] + (width/2))+25), int((loc_max[1] + (height/2)))+25)#+25 offset

                        if draw:
                            output_img = cv2.rectangle(real_img, (int(x_start), int(y_start)), (int(x_end), int(y_end)), (0, 0, 255), 3)
                            output_img = cv2.circle(real_img, center, 4,(255,255,255),-1)
                        else:
                            output_img = real_img

                        #result =  center , output_img
                        return center ,output_img
                        break
                    else:   
                        #result = False , False
                        return False ,real_img
                        break

                ###################################################
                else:
                    #result = False ,False
                    return False ,real_img
                    break

            #return result

        except Exception as e:
            print('find_element function error: \n'+str(e))

    def qrbar_reader(self,img, origcode,draw=True):
        try:
            status = False
            codes = decode(img)
            if len(codes)>0:
                for barcode in codes:
                    curcode = barcode.data.decode('utf-8')
                    print(curcode)
                    if curcode == origcode:
                        status = True
                        myColor = (0,255,0)
                        print('qrbar_reader function found matching a QR/Barcode')
                    else:
                        myColor = (0, 0, 255)
                        print('qrbar_reader function did not find matching a QR/Barcode')
                    print(status)
                    bbox = np.array(barcode.polygon, dtype=np.float32)
                    if draw==True:
                        pts = np.array([barcode.polygon],np.int32)
                        pts = pts.reshape((-1,1,2))
                        cv2.polylines(img,[pts],True,myColor,2)
                    return img, status, bbox
                    if status:
                        break
            else:
                print("QR/Barcode not detected")
                return False, False, False
        except Exception as e:
            print(e)
            
    def qrcode_gen(self, text, filename):
        qr = qrcode.QRCode(
            version=2, #integer from 1 to 40 that controls the size of the QR Code (the smallest, version 1, is a 21x21 matrix)
            error_correction=qrcode.constants.ERROR_CORRECT_H)
        qr.add_data(text)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(self.full_path + filename+".png")
        #...rony......
        text = str(text)
        image = cv2.imread(self.full_path + filename+".png")
        height,width,ch = image.shape
        length = (int(len(text)/2))*16
        new_cent = (width/2) - length
        org = (int(new_cent), int(height-10))
        image = cv2.putText(image, text, org, cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,0), 2, cv2.LINE_AA, False)
        cv2.imwrite(self.full_path + filename+".png",image)   
 
    def sort_keys(self, key_list=[],xd=-1,yd=-1,Primeloc=[]):
        print("xd :",xd)
        print("yd :",yd)
        print("pl :",Primeloc)
        print("kl :",key_list)
        x1,y1 = Primeloc[0], Primeloc[1]
        key_locs = []
        key_names = []
        for key in key_list:
            if key[0] != "":
                key_loc = [(int(x1)+((int(key[2]))*int(xd))),(int(y1)+((int(key[1]))*int(yd)))]
                key_locs.append(key_loc)
                key_names.append(key[0])
        return key_locs #[[xcor,ycor],...] list of centers of keys

    def detect_keys(self, img,template):
        try:
            orb = cv2.ORB_create(2000) #2000 if max no. of features detected
            per=50 #percentage of feature matches
            h,w,c = template.shape
            kp1, des1 = orb.detectAndCompute(template, None)
            kp2, des2 = orb.detectAndCompute(img, None)
            bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
            matches = bf.match(des2,des1)
            matches = list(matches)
            matches.sort(key= lambda x: x.distance)
            good = matches[:int(len(matches)*(per/100))]
            if len(good)>25: #min no. of matchecs = 25
                srcPoints = np.float32([kp2[m.queryIdx].pt for m in good]).reshape(-1,1,2)
                dstPoints = np.float32([kp1[m.trainIdx].pt for m in good]).reshape(-1,1,2)
                M, _ = cv2.findHomography(srcPoints, dstPoints, cv2.RANSAC, 5.0)
                imgScan = cv2.warpPerspective(img,M,(w,h))
                return imgScan,M
            else:
                print('detect_keys function: keys not found')
                return False, False
        except Exception as e:
            print(e)
            
    def indicator_onoff(self, img, colours, whitepx_thresh): #colours = [hmin,smin,vmin,hmax,smax,vmax]
        height, width, channels = img.shape
        total_px = height*width
        for colour in colours:
            col_name = colour[6]
            lower = np.array([colour[0], colour[1], colour[2]])
            upper = np.array([colour[3], colour[4], colour[5]])
            # Create HSV Image and threshold into a range.
            blurred = cv2.bilateralFilter(img, 5, 175, 175)
            hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv, lower, upper)
            cv2.imshow("mask", mask)
            filtered = cv2.bitwise_and(img,img, mask= mask)
            cv2.imshow('filtered',filtered)
            #dst = np.bitwise_not(mask)
            ones = cv2.countNonZero(mask)
            per_white = int((ones/total_px)*200)
            print(per_white)
            if per_white > whitepx_thresh:
                print("on")
                return("on", col_name)
            else:
                print("off")
                return("off", "nill")
            #locs = np.where(mask == 255)
            #pixels = img[locs]
            #print(pixels)
            #print(np.mean(pixels))
            #cv2.imshow("indicator", mask)
    
    def undistort_image(self, image, path, crop=False):
        calib_result_pickle = pickle.load(open(path, "rb" )) #pickle file opened and data extracted
        mtx = calib_result_pickle["mtx"]
        optimal_camera_matrix = calib_result_pickle["optimal_camera_matrix"]
        dist = calib_result_pickle["dist"]
        roi = calib_result_pickle["roi"]
        undistorted_image = cv2.undistort(image, mtx, dist, None, optimal_camera_matrix)
        if crop:
            x, y, w, h = roi
            undistorted_image = undistorted_image[y:y+h, x:x+w]
        return undistorted_image

    def detect_camera_index(self,camera_serial):
        found_camera_index = False
        camera_index = None

        if exists("/dev/v4l/by-id/"):
            for file in os.listdir("/dev/v4l/by-id/"):
                if camera_serial in file:
                    if "index0" in file:
                        camera_index = "/dev/v4l/by-id/"+file
                        found_camera_index = True
                        break

        return found_camera_index,camera_index

    def calculate_camera_matrix(self,img ,crop = True ):
        #img = cv2.imread(img)
        h, w = img.shape[:2]
        # Obtain the new camera matrix and undistort the image
        newCameraMtx, roi = cv2.getOptimalNewCameraMatrix(self.calib['mtx'], self.calib['dist'], (w, h), 1, (w, h))
        undistortedImg = cv2.undistort(img, self.calib['mtx'], self.calib['dist'], None, newCameraMtx)
        if crop == True:
            x, y, w, h = roi
            undistortedImg = undistortedImg[y:y+h,x:x+w]
        return undistortedImg

    def predict_status(self,img):

        resized_img = cv2.resize(img, (224, 224),interpolation = cv2.INTER_NEAREST)
        cv2.imwrite(self.full_path + "temp/status_img_resized.jpg",resized_img)
        image = Image.open(self.full_path + 'temp/status_img_resized.jpg')
        # Create the array of the right shape to feed into the keras model
        # The 'length' or number of images you can put into the array is
        # determined by the first position in the shape tuple, in this case 1.
        data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
        #data = np.ndarray(shape=(1, 251, 284, 3), dtype=np.float32)
        # Replace this with the path to your image
        #image = img#Image.open('e.jpg')
        #resize the image to a 224x224 with the same strategy as in TM2:
        #resizing the image to be at least 224x224 and then cropping from the center
        size = (224, 224)
        #size = (251, 284)
        image = ImageOps.fit(image, size, Image.ANTIALIAS)
        #turn the image into a numpy array
        image_array = np.asarray(image)
        # Normalize the image
        normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1
        #print("normalized_image_array :",normalized_image_array)
        # Load the image into the array
        data[0] = normalized_image_array
        # run the inference
        prediction = self.status_model.predict(data)
        #print("prediction :",prediction)
        #my_file = open("modules/status_detection/labels.txt", "r")
        my_file = open(self.full_path + "config/status_detection/labels.txt", "r")
        # reading the file
        data = my_file.read()
        # replacing end splitting the text 
        # when newline ('\n') is seen.
        #print("data :",data)
        #data = data.split(" ")
        classes = data.split("\n")
        #print(classes)
        my_file.close()
        MaxPosition=np.argmax(prediction)  
        prediction_label=classes[MaxPosition]
        #print(prediction_label)
        prediction_label =prediction_label.split(" ")
        #print(prediction_label[1])
        return prediction_label[1]

    def pgm_status(self,state,action,path):
        status = False

        if action == 'r':
            #if (os.path.exists('/home/sgbi/teach_studio/pgm_status.txt')):
            if (os.path.exists(path + 'pgm_status.txt')):
                run_state = True
            else:
                run_state = False
        else:
            run_state = True

        if run_state == True:
            f = open(path +"pgm_status.txt", action)

            if action == 'w':
                f.write(str(state))
            else:
                data=f.read().replace('\n','')
                if data == '1':
                    status = False
                elif data == '0':
                    status = True
            f.close()

        return status
        
    def resize(self, image, image_size_multi=1):
        #Resize image, integer multiplier, more than 1 for enlarging and less than -1 for reduction
        try:
            height, width, channels = image.shape
            if image_size_multi > 1:
                image_size_multi = image_size_multi
                res_image = cv2.resize(image, (int(width*image_size_multi), int(height*image_size_multi)), interpolation=cv2.INTER_AREA)
                mul=1/image_size_multi
            elif image_size_multi < -1:
                image_size_multi = 1/(-1*(image_size_multi))
                res_image = cv2.resize(image, (int(width*image_size_multi), int(height*image_size_multi)), interpolation=cv2.INTER_LANCZOS4)#cv2.INTER_CUBIC
                mul=1/image_size_multi
            elif image_size_multi == 0 or image_size_multi == 1 or image_size_multi == -1:
                res_image = image
                mul=1
            else:
                res_image = image
                mul=1
            return res_image, mul
        except Exception as e:
            print(e)
    
    def adaptive_thresh(self, image):
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        image = cv2.GaussianBlur(image,(5,5),0)
        high_thresh,image = cv2.threshold(image,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
        return image
    
    def detector(self, image, size=1):
        image, mult = self.resize(image, image_size_multi=size)
        horizontal_list, free_list = globals()["reader_english_g2"].detect(image, min_size=5,add_margin=0)
        return horizontal_list[0], mult
    
    def allowed_char(self, allowlist, num=True, sym=True, upchar=True, lochar=True):
        if allowlist=="":
            allowed = ""
            numbers = '0123456789'
            symbols = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~ "
            lang_char_up = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
            lang_char_lo = 'abcdefghijklmnopqrstuvwxyz'
            if num:
                allowed=allowed+numbers
            if sym:
                allowed=allowed+symbols
            if upchar:
                allowed=allowed+lang_char_up
            if lochar:
                allowed=allowed+lang_char_lo
            return allowed
        else:
            return allowlist

    def text_correction(self, words, dataset):
        try:
            cor_words = []
            for word in words:
                pc_word = difflib.get_close_matches(word, dataset, 1,cutoff =0.4)

                if len(pc_word) != 0:
                    cor_words.append(*pc_word)
                else:
                    cor_words.append(word)
                   
            return cor_words

        except Exception as e:
            print(e)
            return -1

    def similar(self, a, b):
        return SequenceMatcher(None, a, b).ratio()*100
    
    # def text_extract_easyocr(self, image, model, allowlist="", dataset=[], det=1, cor=1, det_mul=-2, sen=0):
    #     #allowlist = self.allowed_char(allowlist)
        
    #     if det:
    #         horizontal_list, mult = self.detector(image,det_mul)
    #         words = []
    #         for i in horizontal_list:
    #             x1,x2,y1,y2 = i
    #             x1,x2,y1,y2 = int(x1*mult),int(x2*mult),int(y1*mult),int(y2*mult)
    #             img1 = image[y1:y2,x1:x2]
    #             img1 =  self.adaptive_thresh(img1)
    #             result = globals()["reader_"+str(model)].recognize(img1, allowlist=str(allowlist),batch_size=3,detail=0)
    #             words.append(result[0])
    #     else:
    #         #image =  self.adaptive_thresh(image)
    #         #words = globals()["reader_"+str(model)].recognize(image, allowlist=str(allowlist),batch_size=3,detail=0)
    #         words = reader_english_g2.readtext(image,allowlist=str(allowlist),batch_size=3,detail=0)



    #     if cor and dataset!=[]:
    #         words = self.text_correction(words,dataset)
    #     if sen:
    #         words = ' '.join(words)
    #     return words

    # def get_position_easyocr(self, image, model, allowlist="",det=True, ocr_text = '' , match_percent = 100, det_mul=-2):
    #     det = False 
    #     #ocr_text = ocr_text.lower()
    #     try:
    #         x,y = (None,None)
    #         status = False
    #         result = None
            
    #         if det:
    #             horizontal_list, mult = self.detector(image,det_mul)
    #             for i in horizontal_list:
    #                 print("I :",i)
    #                 x1,x2,y1,y2 = i
    #                 x1,x2,y1,y2 = int(x1*mult),int(x2*mult),int(y1*mult),int(y2*mult)
    #                 img1 = image[y1:y2,x1:x2]
    #                 img1 =  self.adaptive_thresh(img1)
    #                 result = globals()["reader_"+str(model)].recognize(img1, allowlist=str(allowlist),batch_size=3)
    #                 #words.append(result[0])
    #                 #print(result)
    #                 immg = img1
            
    #         else:
    #             #image =  self.adaptive_thresh(image)
    #             result = reader_english_g2.readtext(image,allowlist=str(allowlist),batch_size=3)
    #             immg = image

    #         print(result)

    #         for i in result:
    #             match_score = int(SequenceMatcher(None, ocr_text.lower(), i[1].lower()).ratio()*100)
    #             if int(match_score) >= int(match_percent) :
    #                 print("Yes Found")

    #                 print("i :",i)
                    
    #                 x1,y1 = i[0][0]
    #                 x2,y2 = i[0][1]
    #                 x3,y3 = i[0][2]
    #                 x4,y4 = i[0][3]
    #                 x = (x2-x1)/2 + x1
    #                 y = (y2-y1)/2 + y1
                    
    #                 x1 = i[0][0][0]
    #                 y1 = i[0][0][1]
    #                 x3 = i[0][2][0]
    #                 y3 = i[0][2][1]

    #                 #x =(x3/2)
    #                 #y =(y3/2)
    #                 x = ((x3-x1)/2) + x1
    #                 y = ((y3-y1)/2) + y1

    #                 tl = tuple(result[0][0][0])
    #                 br = tuple(result[0][0][2])

    #                 #print("top:",tl[0])

    #                 #x = ((br[0] - tl[0])/2) + tl[0]
    #                 #y = ((br[1] - tl[1])/2) + tl[1]

    #                 #print("topl :",top_left)
    #                 #print("bottom_right :",bottom_right)

    #                 status = True
    #                 print("Coord :",x,y)
    #                 #print("Coord2 :",x1,y1)

    #                 break

    #             else:
    #                 status = False

    #         return x,y,status ,immg

    #     except Exception as e:
    #         print(e)
    #         return None,None,False ,None

    # def get_position_easyocr_with_pinmode(self, image , pass_key):

    #     #image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    #     #result = reader_english_g2.readtext(image,allowlist=str(allowlist),batch_size=3)
    #     result = reader_english_g2.readtext(image,batch_size=3)

    #     text_dict = {}
    #     status = False

    #     for i in result:
    #         text = i[1][0]

    #         x1,y1 = i[0][0]
    #         x2,y2 = i[0][1]
    #         x3,y3 = i[0][2]
    #         x4,y4 = i[0][3]
    #         x = (x2-x1)/2 + x1
    #         y = (y2-y1)/2 + y1
            
    #         x1 = i[0][0][0]
    #         y1 = i[0][0][1]
    #         x3 = i[0][2][0]
    #         y3 = i[0][2][1]

    #         co_x = int(((x3-x1)/2) + x1)
    #         co_y = int(((y3-y1)/2) + y1)

    #         text_dict.update({text:(co_x,co_y)})

    #     print("text dict :",text_dict)
    #     for no in pass_key:
    #         if no in text_dict.keys():
    #             status = True
    #         else:
    #             status = False
    #             break

    #     return text_dict, status

    def compare_images(self,imageA,imageB,threshold):

        from skimage.metrics import structural_similarity
        from skimage.color import rgb2gray
        sliding_window_size_x = 5
        sliding_window_size_y = 5

        try:
            # convert the images to grayscale
            grayA = rgb2gray(imageA)
            grayB = rgb2gray(imageB)
            imageA = cv2.fastNlMeansDenoisingColored(imageA, None, 10, 10, 7, 15) 
            imageB = cv2.fastNlMeansDenoisingColored(imageB, None, 10, 10, 7, 15) 
            grayA = rgb2gray(imageA)
            grayB = rgb2gray(imageB)
            mean_filter_kernel = np.ones((sliding_window_size_x,sliding_window_size_y),np.float32)/(sliding_window_size_x*sliding_window_size_y)
            grayA = cv2.filter2D(grayA,-1,mean_filter_kernel)
            grayB = cv2.filter2D(grayB,-1,mean_filter_kernel)
            #(score, diff) = compare_ssim(grayA, grayB, full=True)
            (score, diff) = structural_similarity(grayA, grayB, full=True, data_range=1.0)
            #print("diff",diff)
            diff = (diff * 255).astype("uint8")
            #SSIM_VALUE="SSIM: {}".format(score)

            SSIM_VALUE = score
            print("SSIM VAL :",SSIM_VALUE)

            # threshold the difference image, followed by finding contours to
            # obtain the regions of the two input images that differ
            thresh = cv2.threshold(diff, 0, 255,
                cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
            cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL,
                cv2.CHAIN_APPROX_SIMPLE)
            cnts = imutils.grab_contours(cnts)
            
            if SSIM_VALUE > (threshold/100):
                return True
            
            else:
                return False
        
        except Exception as e:
            print(e)
            return False

    ##OPENCV Filters

    # def rotate_image(self,image,angle):
    #     if angle == 90:
    #         image = cv2.rotate(src, cv2.ROTATE_90_CLOCKWISE)

    #     elif angle == 180:
    #         image = cv2.rotate(src, cv2.ROTATE_180)

    #     elif angle == 270:
    #         image = cv2.rotate(src, cv2.ROTATE_90_COUNTERCLOCKWISE)

    #     return image

    def init_serial_port_byserial(self,serial_no = 'A9J6JFZK'):
        portList = list(serial.tools.list_ports.comports())
        for port in portList:
            if port.serial_number ==  serial_no:
                #serial_port = port[0]
                self.ser = serial.Serial(port[0],115200,timeout = 130)
                self.ser_connected = True
                break

        return self.ser_connected ,self.ser

    def init_serial_port(self,name = '403'):
        portList = list(serial.tools.list_ports.comports())
        for port in portList:
            if name in port[0] or name in port[1] or name in port[2]:
                self.ser = serial.Serial(port[0],115200,timeout = 130)
                self.ser_connected = True
                break

        return self.ser_connected ,self.ser

    def get_current_pos(self,ser):
        c_x,c_y = None , None
        ser.write(('g:\n').encode())
        ser_bytes  = self.ser.readline()
        feedback = ser_bytes.decode("utf-8")
        feedback = feedback.replace('\r', '')
        feedback = feedback.replace('\n', '')
        feedback = feedback.split(':')
        if len(feedback) == 11:
            c_x = round(float(feedback[0]))
            c_y = round(float(feedback[1]))

        if c_x != None and c_y != None:
            got_feedback = True
        else:
            got_feedback = False
        print("c_x :",c_x ,"c_y :",c_y)

        return got_feedback,c_x,c_y
 
    def element_current_pos(self,ser):
        c_x,c_y = None , None
        ser.write(('g:\n').encode())
        ser_bytes  = self.ser.readline()
        feedback = ser_bytes.decode("utf-8")
        feedback = feedback.replace('\r', '')
        feedback = feedback.replace('\n', '')
        feedback = feedback.split(':')
        if len(feedback) == 11:
            c_x = round(float(feedback[0]))
            c_y = round(float(feedback[1]))

        if c_x != None and c_y != None:
            got_feedback = True
        else:
            got_feedback = False
        print("c_x :",c_x ,"c_y :",c_y)

        return {str(c_x)+":"+str(c_y)}
    
    def send_cmd(self,ser,cmd):
        ser.write((cmd+'\n').encode())
        ser_bytes  = ser.readline()
        feedback = ser_bytes.decode("utf-8")
        
        feedback = feedback.replace('\r', '')
        feedback = feedback.replace('\n', '')
        #feedback =int(feedback.rstrip('\x00\x00\n'))    
        return feedback

    def move_robot(self , x_pos , y_pos ,running_step , direction ,ser):
        feedback = ''
        if direction =='up':
            if (y_pos - running_step) >= ROBOT_MIN_Y:
                cmd = "m:" + str(x_pos) + ":" + str( abs( y_pos - running_step )) + ":" + SPEED +":"
                feedback = self.send_cmd(ser,cmd)

        elif direction == 'down':
            if (y_pos + running_step) <= ROBOT_MAX_Y:
                cmd = "m:" + str(x_pos) + ":" + str( y_pos + running_step ) + ":" + SPEED +":"
                feedback = self.send_cmd(ser,cmd)

        elif direction == 'left':
            if (x_pos - running_step) >= ROBOT_MIN_X:
                cmd = "m:" + str( abs(x_pos - running_step )) + ":" + str(y_pos) + ":" + SPEED +":"
                feedback = self.send_cmd(ser,cmd)

        elif direction == 'right':
            if (x_pos + running_step) <= ROBOT_MAX_X:
                cmd = "m:" + str( x_pos + running_step ) + ":" + str(y_pos) + ":" + SPEED +":"
                feedback = self.send_cmd(ser,cmd)

        return feedback

    def base64to_img(self,b64img):
        image_data = base64.b64decode(b64img)
        np_array = np.frombuffer(image_data, np.uint8)
        image = cv2.imdecode(np_array, cv2.IMREAD_COLOR)
        if image is None:
            return None
        
        return image

    def move_robot_by_pixel(self,ser,x,y,action,duration=100,backpos=15,force=300):
        cmd = None 
        # frame = self.base64to_img(base64_string)
        frame = cv2.imread("/home/sgbi/Q_studio/studio_be/app/routers/output_img.jpg")


        #if frame != None:

        height, width, channels = frame.shape
        cam_center = (int(width/2),int(height/2))

        got_feedback,c_x,c_y = self.get_current_pos(ser)

        if got_feedback:

            if action == 'left_click':

                if x < cam_center[0] and y < cam_center[1] :
                    cent = (  x  ,  y )
                    img, x_distance, y_distance = self.find_diff(frame, cam_center, cent, pixel_mm_ratio,draw=False)
                    x_loc = int(abs(c_x - abs(y_distance)))
                    y_loc = int(abs(c_y - abs(x_distance)))
                    cmd = 'm:'+ str(x_loc) + ':' + str(y_loc) + ':' + str(MOVE_SPEED) + ':'

                elif x > cam_center[0] and y < cam_center[1] :
                    cent = (  x  ,  y )
                    img, x_distance, y_distance = self.find_diff(frame, cam_center, cent, pixel_mm_ratio,draw=False)
                    x_loc = int(c_x + abs(y_distance))
                    y_loc = abs(int(c_y - abs(x_distance)))
                    cmd = 'm:'+ str(x_loc) + ':' + str(y_loc) + ':' + str(MOVE_SPEED) + ':'

                elif x < cam_center[0] and y > cam_center[1] :
                    cent = (  x  ,  y )
                    img, x_distance, y_distance = self.find_diff(frame, cam_center, cent, pixel_mm_ratio,draw=False)
                    x_loc = int(abs(c_x - abs(y_distance)))
                    y_loc = int(abs(c_y + abs(x_distance)))
                    cmd = 'm:'+ str(x_loc) + ':' + str(y_loc) + ':' + str(MOVE_SPEED) + ':'

                elif x > cam_center[0] and y > cam_center[1] :
                    cent = (  x  ,  y )
                    img, x_distance, y_distance = self.find_diff(frame, cam_center, cent, pixel_mm_ratio,draw=False)
                    x_loc = int(c_x + abs(y_distance))
                    y_loc = int(c_y + abs(x_distance))
                    cmd = 'm:'+ str(x_loc) + ':' + str(y_loc) + ':' + str(MOVE_SPEED) + ':'

                else:
                    print("center part")
                    x_distance = 0
                    y_distance = 0

                x_loc = int(abs(c_x + x_distance))
                y_loc = int(abs(c_y + y_distance)) 

                if x_loc >= ROBOT_MIN_X and x_loc <= ROBOT_MAX_X and y_loc >= ROBOT_MIN_Y and y_loc <= ROBOT_MAX_Y:
                    cmd = 'm:'+ str(x_loc) + ':' + str(y_loc) + ':' + str(MOVE_SPEED) + ':'
                    feedback = self.send_cmd(ser,cmd)
            
            elif action == 'right_click':

                img, x_distance, y_distance = self.find_diff(frame, cam_center, (x,y), pixel_mm_ratio,draw=True)
                
                print("x Diff :",x_distance)
                print("y Diff :",y_distance)
                print("pixel_mm_ratio :",pixel_mm_ratio)
                
                cv2.imwrite('/home/sgbi/Q_studio/studio_be/app/routers/touch_point_image.jpg',img)
                ###Pro-d
                # x_loc, y_loc = int(c_x + x_distance),int((c_y + y_distance)-45)
                # x_loc = x_loc + OFFSET_X
                # y_loc = y_loc + OFFSET_Y
                ###########

                rx = ((c_x + CAM_OFFSET_X) + x_distance )+ OFFSET_X
                ry = ((c_y + CAM_OFFSET_Y) + y_distance )+ OFFSET_Y
                x_loc, y_loc = int(rx) ,int(ry)

                
                #cmd = 'f:str:' + str(x_loc) + ':' + str(y_loc) + ':' + str(gb.duration) + ':' + str(gb.backpos) + ':' + str(gb.force) + ':' + '&' + 'r:0:' + '&' + 'm:' + str(c_x) + ':' + str(c_y) + ':' + str(gb.move_speed) + ':'
                cmd = 'f:str:' + str(x_loc) + ':' + str(y_loc) + ':' + str(duration) + ':' + str(backpos) + ':' + str(force) + ':'
                print("Final cmd :",cmd)
                feedback = self.send_cmd(ser,cmd)

        else:
            feedback = '1'


        return cmd, feedback

    def crop_image(self,image):
        image = image[CROP_START_Y:CROP_END_Y, CROP_START_X:CROP_END_X]
        return image

    def center_to_mm_prod(self,cmd,cent ,c_x,c_y,real_img):

        height, width, channels = real_img.shape
        cam_center = (int(width/2),int(height/2))

        img, x_distance, y_distance = self.find_diff(real_img, cam_center, cent, pixel_mm_ratio,draw=True)
        
        print("x Diff :",x_distance)
        print("y Diff :",y_distance)

        if cmd[0] == 'f':
            if cmd[1] == 'st' or cmd[1] == 'str' or cmd[1] == 'mt' or cmd[1] == 'mtr' or cmd[1] == 'th' or cmd[1] == 'd' or cmd[1] == 'st:l' or cmd[1] == 'str:l':
               
                offset_y = abs(c_y - 41.5)
                x_loc, y_loc = int(c_x + x_distance),int((c_y + y_distance)-45)

        elif cmd[0] == 'm':

            offset_y = abs(c_y - 41.5)
            x_loc, y_loc = int(c_x + x_distance),int((c_y + y_distance)-45)

        
        x_loc = x_loc + OFFSET_X
        y_loc = y_loc + OFFSET_Y

        real_cmd = str(x_loc) + ':' + str(y_loc)

        return real_cmd

    def center_to_mm(self,cmd,cent ,x,y):
        frame = cv2.imread("/home/sgbi/Q_studio/studio_be/app/routers/output_img.jpg")
        
        height, width, channels = frame.shape
        cam_center = (int(width/2),int(height/2))
        print("ccceeennntttt :",cent)
        print("pix mm :",pixel_mm_ratio)
        img, x_distance, y_distance = self.find_diff(frame, cam_center, cent, pixel_mm_ratio,draw=True)        
        print("x Diff :",x_distance)
        print("y Diff :",y_distance)

        if cmd[0] == 'f':
            if cmd[1] == 'st' or cmd[1] == 'str' or cmd[1] == 'mt' or cmd[1] == 'mtr' or cmd[1] == 'th' or cmd[1] == 'd':
                rx = ((x + CAM_OFFSET_X) + x_distance )+ OFFSET_X
                ry = ((y + CAM_OFFSET_Y) + y_distance )+ OFFSET_Y
                x_loc, y_loc = int(rx) ,int(ry)

        elif cmd[0] == 'm':
            offset = x + (67.5)
            x_loc, y_loc = int(offset + x_distance),int(y+int(y_distance))

        elif cmd[0] == 's':
            rx = ((x + CAM_OFFSET_X) + x_distance )+ OFFSET_X
            ry = ((y + CAM_OFFSET_Y) + y_distance )+ OFFSET_Y
            x_loc, y_loc = int(rx) ,int(ry)

        real_cmd = str(x_loc) + ':' + str(y_loc)
    
        return real_cmd
    
