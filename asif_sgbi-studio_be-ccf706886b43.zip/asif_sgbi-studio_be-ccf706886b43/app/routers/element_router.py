from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
# from studio_be.app import database
from . .import crud, schemas, database
from .modules import Teach_Modules
import cv2
import base64
import logging

teach_modules = Teach_Modules()
# from .database import get_db  # Adjust import based on your project structure
status,sr = teach_modules.init_serial_port()

logger = logging.getLogger(__name__)


def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

router = APIRouter()


# Dut Buttons API's
@router.post("/create_buttons/", response_model=schemas.DutButtonsInDB)
def create_dut_button(dut_button: schemas.DutButtonsCreate,db: Session = Depends(get_db)):
    """
    Create a new DUT button with the current element position.

    Args:
        dut_button (schemas.DutButtonsCreate): The button data to create.
        db (Session, optional): Database session dependency.

    Returns:
        schemas.DutButtonsInDB: The created DUT button.
    """
    try:
        logger.info("Fetching the current element position.")
        button_pos = teach_modules.element_current_pos(sr)
        button_pos = next(iter(button_pos))
        
        logger.info(f"Creating a new DUT button with position: {button_pos}")
        new_button = crud.create_dut_button(db=db, dut_button=dut_button, button_pos=button_pos)
        
        logger.info(f"DUT button created successfully: {new_button.id}")
        return new_button
    except Exception as e:
        logger.error(f"Error creating DUT button: {e}")
        raise HTTPException(status_code=500, detail="An error occurred while creating the DUT button.")
    


@router.get("/get_dut_buttons/{button_id}", response_model=schemas.DutButtonsInDB)
def read_dut_button(button_id: int, db: Session = Depends(get_db)):
    db_button = crud.get_dut_button(db, button_id)
    if db_button is None:
        raise HTTPException(status_code=404, detail="Dut button not found")
    return db_button

# @router.get("/dut_buttons/", response_model=List[schemas.DutButtonsInDB])
# def read_dut_buttons(dut_id: int, skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
#     return crud.get_dut_buttons(db, dut_id, skip=skip, limit=limit)

@router.put("/dut_buttons/{button_id}", response_model=schemas.DutButtonsInDB)
def update_dut_button(button_id: int, dut_button: schemas.DutButtonsUpdate, db: Session = Depends(get_db)):
    try:
        # Fetch the current button position
        button_pos = teach_modules.element_current_pos(sr)
        button_pos = next(iter(button_pos))  # Extract position

        # Update the button using CRUD operation
        db_button = crud.update_dut_button(db, button_id, dut_button, button_pos)
        if db_button is None:
            logger.error(f"Dut Button with ID {button_id} not found")  # Log error if button not found
            raise HTTPException(status_code=404, detail="Dut button not found")

        # Log success
        logger.info(f"Dut Button with ID {button_id} successfully updated")  
        return db_button

    except Exception as e:
        # Log any unexpected error
        logger.error(f"Error updating Dut Button with ID {button_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

@router.delete("/dut_buttons/{button_id}", response_model=schemas.DutButtonsInDB)
def delete_dut_button(
    button_id: int, 
    db: Session = Depends(get_db)
):
    """
    Delete a DUT button by its ID.

    Args:
        button_id (int): The ID of the DUT button to delete.
        db (Session, optional): Database session dependency.

    Returns:
        schemas.DutButtonsInDB: The deleted DUT button information.
    """
    try:
        logger.info(f"Attempting to delete DUT button with ID: {button_id}")
        db_button = crud.delete_dut_button(db, button_id)
        
        if db_button is None:
            logger.warning(f"DUT button with ID {button_id} not found.")
            raise HTTPException(status_code=404, detail="DUT button not found")
        
        logger.info(f"DUT button with ID {button_id} deleted successfully.")
        return db_button
    except Exception as e:
        logger.error(f"Error deleting DUT button with ID {button_id}: {e}")
        raise HTTPException(status_code=500, detail="An error occurred while deleting the DUT button.")

@router.get("/buttons/by_dut/{dut_id}", response_model=List[schemas.DutButtonsInDB])
def get_buttons_by_dut_id(dut_id: int, db: Session = Depends(get_db)):

    buttons = crud.get_dut_buttons(db=db, dut_id=dut_id)
    if not buttons:

        # raise HTTPException(status_code=404, detail="No buttons found for the specified DUT")
        return buttons

    return buttons

# DUT Screen API's

@router.post("/dut_screens/", response_model=schemas.DutScreensInDB)
def create_dut_screen(dut_screen: schemas.DutScreensCreate, db: Session = Depends(get_db)):
    screen_pos = teach_modules.element_current_pos(sr)
    screen_pos = next(iter(screen_pos))

    return crud.create_dut_screen(db=db, dut_screen=dut_screen, screen_pos = screen_pos)

@router.get("/dut_screens/{screen_id}", response_model=schemas.DutScreensInDB)
def read_dut_screen(screen_id: int, db: Session = Depends(get_db)):
    db_screen = crud.get_dut_screen(db, screen_id)
    if db_screen is None:
        raise HTTPException(status_code=404, detail="Dut screen not found")
    return db_screen


@router.get("/screens_by_dut/{dut_id}", response_model=List[schemas.DutScreensInDB])
def dut_screens_by_dut_id(dut_id: int, db: Session = Depends(get_db)):
    return crud.get_dut_screens_by_dut_id(db=db, dut_id=dut_id)


@router.put("/update_dut_screens/{screen_id}", response_model=schemas.DutScreensInDB)
def update_dut_screen(screen_id: int, dut_screen: schemas.DutScreensUpdate, db: Session = Depends(get_db)):
    screen_pos = teach_modules.element_current_pos(sr)
    screen_pos = next(iter(screen_pos))
    db_screen = crud.update_dut_screen(db, screen_id, dut_screen, screen_pos)
    if db_screen is None:
        raise HTTPException(status_code=404, detail="Dut screen not found")
    return db_screen


@router.delete("/delete_dut_screens/{screen_id}", response_model=schemas.DutScreensInDB)
def delete_dut_screen(screen_id: int, db: Session = Depends(get_db)):
    db_screen = crud.delete_dut_screen(db, screen_id)
    if db_screen is None:
        raise HTTPException(status_code=404, detail="Dut screen not found")
    return db_screen



# frame_state = shared_state.FrameState()

# @router.get("/dut_button/{button_id}", response_model=schemas.DutButtonsInDB)
# def get_dut_button_details(button_id: int, db: Session = Depends(get_db)):
#     db_button = crud.get_dut_button(db, button_id)
#     if db_button is None:
#         raise HTTPException(status_code=404, detail="Dut button not found")
#     print(db_button)
#     element_pos = db_button.button_position
#     cmd = "m:"+ element_pos +":100:"
#     pos = teach_modules.send_cmd(sr,cmd)

#     light = int(db_button.light)
#     cmd =  "l:"+ str(light) + ":"
    
#     pos = teach_modules.send_cmd(sr,cmd)
#     btn_image = db_button.button_image
#     btn_roi = db_button.button_roi
#     print(btn_roi)
#     btn_roi = btn_roi.split(":")
#     print(btn_roi)
#     element_point = [[int(btn_roi[0]),int(btn_roi[1])],[int(btn_roi[2]),int(btn_roi[3])]]
#     print(element_point)

#     img = frame_state.get_frame()
#     print(img)

#     # import cv2
#     # img = cv2.imread('live.jpg')
#     # cv2.imwrite('1st.jpg',img)
#     # cv2.imwrite('2nd.jpg',btn_image)
#     out , cent , i = teach_modules.find_element(img, btn_image,element_point,rotation=True )

#     print(cent , i)

#     return True

from .captureimage import*

@router.post("/crop_btn/{x}/{y}/{x2}/{y2}")
def crop_btn_from_image(x: int, y: int, x2: int, y2: int):
    try:
        # Capture and save the image first (ensure the function is properly defined)
        capture_and_save_image()
        x = x
        y = y
        # Calculate the end coordinates for cropping
        x2 = x2 + x
        y2 = y2 + y

        # Define the path to the image
        input_image_path = "/home/sgbi/Q_studio/studio_be/app/routers/output_img.jpg"
        output_image_path = "/home/sgbi/Q_studio/studio_be/app/routers/cropped_image.jpg"


        # Check if the image exists
        if not os.path.exists(input_image_path):
            raise HTTPException(status_code=404, detail="Image not found")

        # Load the image using OpenCV
        image = cv2.imread(input_image_path)

        # Validate if the image was loaded properly
        if image is None:
            raise HTTPException(status_code=500, detail="Failed to load the image")

        # Print debug information
        print(f"Cropping coordinates: ({x}, {y}) to ({x2}, {y2})")

        # Crop the image using slicing
        cropped_image = image[y:y2, x:x2]
        cv2.imwrite(output_image_path, cropped_image)
        # Validate if cropping was successful
        if cropped_image.size == 0:
            raise HTTPException(status_code=400, detail="Invalid crop dimensions")

        # Encode the cropped image to Base64
        _, buffer = cv2.imencode('.jpg', cropped_image)
        cropped_image_base64 = base64.b64encode(buffer).decode('utf-8')
        print(cropped_image_base64)
        # Return the Base64 string as a JSON response
        return {"cropped_image_base64": cropped_image_base64}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))